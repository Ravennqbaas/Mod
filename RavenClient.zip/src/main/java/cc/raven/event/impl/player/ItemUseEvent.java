package cc.raven.event.impl.player;

import cc.raven.event.Event;

public class ItemUseEvent extends Event {}