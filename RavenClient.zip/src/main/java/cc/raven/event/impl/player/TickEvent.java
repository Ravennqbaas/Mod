package cc.raven.event.impl.player;

import cc.raven.event.Event;

public class TickEvent extends Event {
    private final Phase phase;
    public TickEvent(Phase phase) { this.phase = phase; }
    public Phase getPhase() { return phase; }
    public enum Phase { PRE, POST }
}