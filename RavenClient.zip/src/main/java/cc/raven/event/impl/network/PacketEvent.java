package cc.raven.event.impl.network;

import cc.raven.event.Event;
import cc.raven.event.types.TransferOrder;
import net.minecraft.network.packet.Packet;

public class PacketEvent extends Event {
    private final Packet<?> packet;
    private final TransferOrder order;
    public PacketEvent(Packet<?> packet, TransferOrder order) { this.packet = packet; this.order = order; }
    public Packet<?> getPacket() { return packet; }
    public TransferOrder getOrder() { return order; }
    @SuppressWarnings("unchecked")
    public <T extends Packet<?>> T getPacketAs() { return (T) packet; }
}