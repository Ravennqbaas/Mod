package cc.raven.event.impl.render;

import cc.raven.event.Event;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class Render2DEvent extends Event {
    private final DrawContext context;
    private final RenderTickCounter tickCounter;
    public Render2DEvent(DrawContext context, RenderTickCounter tickCounter) { this.context = context; this.tickCounter = tickCounter; }
    public DrawContext getContext() { return context; }
    public int getWidth() { return context.getScaledWindowWidth(); }
    public int getHeight() { return context.getScaledWindowHeight(); }
}