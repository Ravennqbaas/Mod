package cc.raven.event.impl.world;

import cc.raven.event.Event;
import net.minecraft.client.world.ClientWorld;

public class WorldChangeEvent extends Event {
    private final ClientWorld world;
    public WorldChangeEvent(ClientWorld world) { this.world = world; }
    public ClientWorld getWorld() { return world; }
}