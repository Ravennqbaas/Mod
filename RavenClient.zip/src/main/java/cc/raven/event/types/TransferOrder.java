package cc.raven.event.types;

public enum TransferOrder { SEND, RECEIVE }