package cc.raven.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EventBus {

    private final Map<Class<? extends Event>, List<RegisteredListener>> listeners = new ConcurrentHashMap<>();
    private final Set<Object> registeredObjects = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public void register(Object object) {
        if (registeredObjects.contains(object)) return;
        registeredObjects.add(object);
        for (Method method : object.getClass().getDeclaredMethods()) {
            if (method.isAnnotationPresent(EventTarget.class)) {
                Class<?>[] params = method.getParameterTypes();
                if (params.length == 1 && Event.class.isAssignableFrom(params[0])) {
                    @SuppressWarnings("unchecked")
                    Class<? extends Event> eventClass = (Class<? extends Event>) params[0];
                    EventTarget annotation = method.getAnnotation(EventTarget.class);
                    RegisteredListener listener = new RegisteredListener(object, method, annotation.priority());
                    listeners.computeIfAbsent(eventClass, k -> new ArrayList<>()).add(listener);
                }
            }
        }
        listeners.values().forEach(list -> list.sort(Comparator.comparingInt(RegisteredListener::getPriority)));
    }

    public void unregister(Object object) {
        registeredObjects.remove(object);
        listeners.values().forEach(list -> list.removeIf(l -> l.getOwner() == object));
        listeners.entrySet().removeIf(entry -> entry.getValue().isEmpty());
    }

    public <T extends Event> T post(T event) {
        List<RegisteredListener> eventListeners = listeners.get(event.getClass());
        if (eventListeners != null) {
            for (RegisteredListener listener : new ArrayList<>(eventListeners)) {
                try {
                    listener.getMethod().invoke(listener.getOwner(), event);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (event.isCancelled()) break;
            }
        }
        return event;
    }

    private static class RegisteredListener {
        private final Object owner;
        private final Method method;
        private final byte priority;
        public RegisteredListener(Object owner, Method method, byte priority) {
            this.owner = owner; this.method = method; this.priority = priority;
        }
        public Object getOwner() { return owner; }
        public Method getMethod() { return method; }
        public byte getPriority() { return priority; }
    }
}