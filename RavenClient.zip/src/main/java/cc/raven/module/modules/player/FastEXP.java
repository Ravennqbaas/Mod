package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public final class FastEXP extends Module {
    private final NumberSetting chance = new NumberSetting("Chance %", 1, 100, 75, 1);

    public FastEXP() { super("Fast Exp", "Fast EXP bottle throwing", Category.PLAYER); addSettings(chance); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (mc.player.getMainHandStack().getItem() != Items.EXPERIENCE_BOTTLE) return;
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_2) != GLFW.GLFW_PRESS) return;
        if (chance.getValue() >= Math.random() * 100) ((MinecraftClientAccessor) mc).invokeDoItemUse();
    }
}