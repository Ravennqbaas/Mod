package cc.raven.module.modules.misc;

import cc.raven.RavenClient;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.client.MinecraftClient;
import java.nio.file.*;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.nio.file.attribute.FileTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

public final class PanicButton extends Module {
    private final SecureRandom random = new SecureRandom();

    public PanicButton() { super("Panic Button", "Disables all modules and cleans traces", Category.MISC); }

    @Override public void onEnable() {
        if (mc.player == null) return;
        ChatUtil.addChatMessage("§4§lPANIC! §fCleaning traces...");
        for (Module m : RavenClient.INSTANCE.getModuleManager().getModules()) if (m.isEnabled() && m != this) m.setEnabled(false);
        new Thread(() -> {
            try {
                Path gameDir = mc.runDirectory.toPath();
                Path configDir = gameDir.resolve("config/RavenClient");
                Path logsDir = gameDir.resolve("logs");
                if (Files.exists(configDir)) Files.walk(configDir).sorted(Comparator.reverseOrder()).forEach(p -> { try { if (Files.size(p) > 0) { byte[] j = new byte[(int)Files.size(p)]; random.nextBytes(j); Files.write(p, j); } Files.deleteIfExists(p); } catch (Exception ignored) {} });
                if (Files.exists(logsDir)) Files.list(logsDir).forEach(p -> { try { if (p.toString().endsWith(".log.gz") || p.toString().endsWith(".log")) { if (Files.size(p) < 100000) { byte[] j = new byte[(int)Files.size(p)]; random.nextBytes(j); Files.write(p, j); } Files.deleteIfExists(p); } } catch (Exception ignored) {} });
                Path prefetch = Paths.get("C:\\Windows\\Prefetch");
                if (Files.exists(prefetch)) Files.list(prefetch).forEach(p -> { String n = p.getFileName().toString().toUpperCase(); if ((n.contains("JAVA") || n.contains("RAVEN") || n.contains("GHOST") || n.contains("ENI")) && n.endsWith(".PF")) { try { Files.deleteIfExists(p); } catch (Exception ignored) {} } });
                for (String log : new String[]{"Microsoft-Windows-Kernel-File/Operational", "Security", "System", "Application"}) try { new ProcessBuilder("wevtutil", "cl", log).start().waitFor(3, TimeUnit.SECONDS); } catch (Exception ignored) {}
                System.gc(); System.runFinalization();
            } catch (Exception ignored) {}
        }).start();
        setEnabled(false);
    }
}