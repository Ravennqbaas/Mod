package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.MathUtils;
import cc.raven.utils.math.TimerUtil;
import cc.raven.utils.mc.InventoryUtil;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;

import java.util.Random;

public final class KeyCrystal extends Module {
    private final NumberSetting minBreak = new NumberSetting("Min Break Delay", 10, 500, 50, 1);
    private final NumberSetting maxBreak = new NumberSetting("Max Break Delay", 10, 500, 100, 1);
    private final NumberSetting minPlace = new NumberSetting("Min Place Delay", 10, 500, 30, 1);
    private final NumberSetting maxPlace = new NumberSetting("Max Place Delay", 10, 500, 80, 1);
    private final BooleanSetting antiSuicide = new BooleanSetting("Anti Suicide", true);
    private final TimerUtil breakTimer = new TimerUtil(), placeTimer = new TimerUtil();
    private final Random random = new Random();
    private long currentBreak, currentPlace;
    private boolean active;

    public KeyCrystal() {
        super("Key Crystal", "Advanced crystal PvP", Category.COMBAT);
        addSettings(minBreak, maxBreak, minPlace, maxPlace, antiSuicide);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean pressed = org.lwjgl.glfw.GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 3) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        if (pressed && !active) { active = true; resetDelays(); }
        else if (!pressed && active) { active = false; return; }
        if (!active) return;
        if (antiSuicide.getValue() && !mc.player.isOnGround()) return;

        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity crystal && crystal.isAlive() && breakTimer.hasElapsedTime(currentBreak)) {
            ((MinecraftClientAccessor) mc).invokeDoAttack();
            breakTimer.reset(); currentBreak = MathUtils.randomIntBetween(minBreak.getValueInt(), maxBreak.getValueInt());
            return;
        }
        if (mc.crosshairTarget instanceof BlockHitResult bhr && placeTimer.hasElapsedTime(currentPlace)) {
            BlockPos target = bhr.getBlockPos();
            BlockPos place = target.offset(bhr.getSide());
            var block = mc.world.getBlockState(target).getBlock();
            if ((block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) && mc.world.getBlockState(place).isAir() && mc.world.getBlockState(place.up()).isAir()) {
                InventoryUtil.swapToSlot(Items.END_CRYSTAL);
                ((MinecraftClientAccessor) mc).invokeDoItemUse();
                placeTimer.reset(); currentPlace = MathUtils.randomIntBetween(minPlace.getValueInt(), maxPlace.getValueInt());
            }
        }
    }

    private void resetDelays() {
        breakTimer.reset(); placeTimer.reset();
        currentBreak = MathUtils.randomIntBetween(minBreak.getValueInt(), maxBreak.getValueInt());
        currentPlace = MathUtils.randomIntBetween(minPlace.getValueInt(), maxPlace.getValueInt());
    }
}