package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.modules.misc.Teams;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.utils.friend.FriendManager;
import cc.raven.utils.render.RendererUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.joml.Matrix4f;
import java.awt.Color;

public final class RavenESP extends Module {
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting invisibles = new BooleanSetting("Invisibles", true);
    private final ColorSetting color = new ColorSetting("Color", new Color(200, 50, 50, 200));
    private final ColorSetting friendColor = new ColorSetting("Friend Color", new Color(50, 200, 100, 200));

    public RavenESP() { super("Raven ESP", "Raven-themed player ESP", Category.RENDER); addSettings(players, invisibles, color, friendColor); }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull()) return;
        RendererUtils.setupRender(); RenderSystem.disableDepthTest();
        var matrices = event.getMatrixStack();
        var camera = mc.gameRenderer.getCamera().getPos();
        var buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        var matrix = matrices.peek().getPositionMatrix();

        for (Entity e : mc.world.getEntities()) {
            if (!isValid(e)) continue;
            Color c = (e instanceof PlayerEntity && FriendManager.isFriend(e.getUuid())) ? friendColor.getValue() : color.getValue();
            float r = c.getRed() / 255f, g = c.getGreen() / 255f, b = c.getBlue() / 255f, a = c.getAlpha() / 255f;
            double dx = e.getX() - camera.x, dy = e.getY() - camera.y, dz = e.getZ() - camera.z;
            float w = e.getWidth() / 2f, h = e.getHeight();
            buffer.vertex(matrix, (float)(dx-w), (float)dy, (float)(dz-w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx+w), (float)dy, (float)(dz-w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx+w), (float)dy, (float)(dz+w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx-w), (float)dy, (float)(dz+w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx-w), (float)(dy+h), (float)(dz-w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx+w), (float)(dy+h), (float)(dz-w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx+w), (float)(dy+h), (float)(dz+w)).color(r,g,b,a*0.3f).next();
            buffer.vertex(matrix, (float)(dx-w), (float)(dy+h), (float)(dz+w)).color(r,g,b,a*0.3f).next();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableDepthTest(); RendererUtils.endRender();
    }

    private boolean isValid(Entity e) {
        if (e == mc.player || e == mc.cameraEntity) return false;
        if (e instanceof PlayerEntity) { if (Teams.isTeammate(e)) return false; if (e.isInvisible() && !invisibles.getValue()) return false; return players.getValue(); }
        return false;
    }
}