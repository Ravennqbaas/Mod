package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.Items;

public final class AutoFirework extends Module {
    private final BooleanSetting onlyWhenFlying = new BooleanSetting("Only When Flying", true);
    private final BooleanSetting autoSwitchBack = new BooleanSetting("Auto Switch Back", true);
    private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 25, 1000, 100, 25);
    private final TimerUtil timer = new TimerUtil();
    private boolean pendingSwitchBack;
    private int originalSlot = -1;
    private long lastFirework;

    public AutoFirework() {
        super("Auto Firework", "Automatically uses fireworks while elytra flying", Category.MOVEMENT);
        addSettings(onlyWhenFlying, autoSwitchBack, switchBackDelay);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (pendingSwitchBack && timer.hasElapsedTime(switchBackDelay.getValueInt())) {
            if (originalSlot != -1) mc.player.getInventory().selectedSlot = originalSlot;
            pendingSwitchBack = false; originalSlot = -1;
        }

        if (!mc.options.useKey.isPressed()) return;
        if (onlyWhenFlying.getValue() && !mc.player.isFallFlying()) return;
        if (mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() != Items.ELYTRA) return;
        if (System.currentTimeMillis() - lastFirework < 200) return;

        int fwSlot = -1;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() instanceof FireworkRocketItem) { fwSlot = i; break; }
        if (fwSlot == -1) return;

        originalSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = fwSlot;
        ((MinecraftClientAccessor) mc).invokeDoItemUse();
        lastFirework = System.currentTimeMillis();

        if (autoSwitchBack.getValue()) {
            if (switchBackDelay.getValueInt() > 0) { pendingSwitchBack = true; timer.reset(); }
            else mc.player.getInventory().selectedSlot = originalSlot;
        }
    }
}