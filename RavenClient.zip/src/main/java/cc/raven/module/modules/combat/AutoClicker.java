package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;

public class AutoClicker extends Module {
    private final NumberSetting cps = new NumberSetting("CPS", 1, 20, 10, 1);
    private final BooleanSetting onlyWeapons = new BooleanSetting("Only Weapons", true);
    private final TimerUtil timer = new TimerUtil();

    public AutoClicker() {
        super("Auto Clicker", "Automatically clicks for you", Category.COMBAT);
        addSettings(cps, onlyWeapons);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.options.attackKey.isPressed()) return;
        if (onlyWeapons.getValue() && !(mc.player.getMainHandStack().getItem() instanceof SwordItem || mc.player.getMainHandStack().getItem() instanceof AxeItem)) return;
        if (timer.hasElapsedTime((long)(1000.0/cps.getValue()), true)) ((MinecraftClientAccessor)mc).invokeDoAttack();
    }
}