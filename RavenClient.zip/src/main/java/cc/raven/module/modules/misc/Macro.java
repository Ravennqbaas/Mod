package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.KeybindSetting;
import cc.raven.module.setting.ModeSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public final class Macro extends Module {
    private final ModeSetting item1 = new ModeSetting("Item 1", "Bow", "Bow", "Ender Pearl", "Wind Charge", "Splash Potion", "Totem", "Sword", "Shield", "Redstone Block", "Piston", "Observer", "TNT", "Cobweb", "Obsidian", "End Crystal", "Anchor", "Glowstone");
    private final ModeSetting item2 = new ModeSetting("Item 2", "Ender Pearl", "Bow", "Ender Pearl", "Wind Charge", "Splash Potion", "Totem", "Sword", "Shield", "Redstone Block", "Piston", "Observer", "TNT", "Cobweb", "Obsidian", "End Crystal", "Anchor", "Glowstone");
    private final KeybindSetting macroKey = new KeybindSetting("Macro Key", GLFW.GLFW_KEY_V, false);
    private final NumberSetting delay = new NumberSetting("Delay", 0, 500, 80, 10);
    private final TimerUtil timer = new TimerUtil();
    private boolean active, keyWasPressed;
    private int step, originalSlot;

    public Macro() { super("Macro", "Use item 1 then item 2 quickly", Category.MISC); addSettings(item1, item2, macroKey, delay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), macroKey.getKeyCode()) == GLFW.GLFW_PRESS;
        if (pressed && !keyWasPressed) { active = true; step = 0; originalSlot = mc.player.getInventory().selectedSlot; timer.reset(); }
        keyWasPressed = pressed;
        if (!active || !timer.hasElapsedTime(delay.getValueInt(), true)) return;

        Item target = step == 0 ? getItem(item1.getMode()) : getItem(item2.getMode());
        int slot = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == target) { slot = i; break; }
        if (slot == -1) { finish(); return; }
        mc.player.getInventory().selectedSlot = slot;
        if (target instanceof net.minecraft.item.BlockItem) { if (mc.crosshairTarget instanceof BlockHitResult) ((MinecraftClientAccessor)mc).invokeDoItemUse(); }
        else if (target == Items.SHIELD) mc.options.useKey.setPressed(true);
        else if (target == Items.DIAMOND_SWORD || target == Items.DIAMOND_AXE) { if (mc.crosshairTarget instanceof EntityHitResult) ((MinecraftClientAccessor)mc).invokeDoAttack(); }
        else ((MinecraftClientAccessor)mc).invokeDoItemUse();
        step++; if (step > 1) finish();
    }

    private void finish() { if (originalSlot != -1) mc.player.getInventory().selectedSlot = originalSlot; active = false; step = 0; }
    private Item getItem(String n) { return switch(n) { case "Bow" -> Items.BOW; case "Ender Pearl" -> Items.ENDER_PEARL; case "Wind Charge" -> Items.WIND_CHARGE; case "Splash Potion" -> Items.SPLASH_POTION; case "Totem" -> Items.TOTEM_OF_UNDYING; case "Sword" -> Items.DIAMOND_SWORD; case "Shield" -> Items.SHIELD; case "Redstone Block" -> Items.REDSTONE_BLOCK; case "Piston" -> Items.PISTON; case "Observer" -> Items.OBSERVER; case "TNT" -> Items.TNT; case "Cobweb" -> Items.COBWEB; case "Obsidian" -> Items.OBSIDIAN; case "End Crystal" -> Items.END_CRYSTAL; case "Anchor" -> Items.RESPAWN_ANCHOR; case "Glowstone" -> Items.GLOWSTONE; default -> Items.BOW; }; }
}