package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class Scaffold extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 0, 200, 30, 5);
    private final BooleanSetting tower = new BooleanSetting("Tower", true);
    private final TimerUtil timer = new TimerUtil();

    public Scaffold() { super("Scaffold", "Auto bridge", Category.MOVEMENT); addSettings(delay, tower); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        BlockPos below = mc.player.getBlockPos().down();
        if (mc.world.getBlockState(below).isAir()) placeBlock(below);
        if (tower.getValue() && mc.options.jumpKey.isPressed() && mc.world.getBlockState(mc.player.getBlockPos().down()).isSolidBlock(mc.world, mc.player.getBlockPos().down())) {
            mc.player.jump(); mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
        }
    }

    private void placeBlock(BlockPos pos) {
        int slot = -1;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() instanceof BlockItem) { slot = i; break; }
        if (slot == -1) return;
        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false));
        mc.player.getInventory().selectedSlot = prev;
    }
}