package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.EntityHitResult;

public final class NoEntityTrace extends Module {
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting weaponsOnly = new BooleanSetting("Weapons Only", true);

    public NoEntityTrace() { super("No Entity Trace", "Hit through entities", Category.PLAYER); addSettings(players, weaponsOnly); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (weaponsOnly.getValue() && !(mc.player.getMainHandStack().getItem() instanceof SwordItem || mc.player.getMainHandStack().getItem() instanceof AxeItem)) return;
        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof net.minecraft.entity.player.PlayerEntity && players.getValue()) mc.crosshairTarget = null;
    }
}