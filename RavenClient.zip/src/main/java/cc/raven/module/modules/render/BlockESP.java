package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.module.setting.ModeSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.render.RendererUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.*;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public final class BlockESP extends Module {
    private final ModeSetting blockType = new ModeSetting("Block", "Diamond", "Diamond", "Emerald", "Gold", "Iron", "Spawner", "AncientDebris", "AllOres");
    private final NumberSetting range = new NumberSetting("Range", 8, 128, 64, 8);
    private final ColorSetting color = new ColorSetting("Color", new Color(0, 255, 255, 200));
    private final BooleanSetting throughWalls = new BooleanSetting("Through Walls", true);

    public BlockESP() { super("Block ESP", "Highlights valuable blocks", Category.RENDER); addSettings(blockType, range, color, throughWalls); }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull()) return;
        List<BlockPos> blocks = findBlocks();
        if (blocks.isEmpty()) return;

        RendererUtils.setupRender();
        if (throughWalls.getValue()) RenderSystem.disableDepthTest();

        var matrices = event.getMatrixStack();
        var camera = mc.gameRenderer.getCamera().getPos();
        var tessellator = Tessellator.getInstance();
        var buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        var matrix = matrices.peek().getPositionMatrix();
        Color c = color.getValue();
        float r = c.getRed() / 255f, g = c.getGreen() / 255f, b = c.getBlue() / 255f, a = c.getAlpha() / 255f;

        for (BlockPos pos : blocks) {
            double dx = pos.getX() - camera.x, dy = pos.getY() - camera.y, dz = pos.getZ() - camera.z;
            float x1 = (float)dx, y1 = (float)dy, z1 = (float)dz, x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;
            buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y1, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y1, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y1, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y2, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y2, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y2, z2).color(r, g, b, a * 0.3f).next();
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        if (throughWalls.getValue()) RenderSystem.enableDepthTest();
        RendererUtils.endRender();
    }

    private List<BlockPos> findBlocks() {
        List<BlockPos> result = new ArrayList<>();
        int r = range.getValueInt();
        BlockPos center = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = center.add(x, y, z);
            if (isTarget(mc.world.getBlockState(pos).getBlock())) result.add(pos);
        }
        return result;
    }

    private boolean isTarget(Block b) {
        return switch (blockType.getMode()) {
            case "Diamond" -> b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE;
            case "Emerald" -> b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE;
            case "Gold" -> b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE;
            case "Iron" -> b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE;
            case "Spawner" -> b == Blocks.SPAWNER;
            case "AncientDebris" -> b == Blocks.ANCIENT_DEBRIS;
            case "AllOres" -> b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE || b == Blocks.EMERALD_ORE || b == Blocks.ANCIENT_DEBRIS || b == Blocks.SPAWNER;
            default -> false;
        };
    }
}