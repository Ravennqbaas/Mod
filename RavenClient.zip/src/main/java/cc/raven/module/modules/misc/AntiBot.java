package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.entity.player.PlayerEntity;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class AntiBot extends Module {
    private final Set<UUID> bots = new HashSet<>();

    public AntiBot() { super("AntiBot", "Detects and ignores bots", Category.MISC); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) != null && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()).getLatency() == 0) bots.add(p.getUuid());
            if (p.getUuid().toString().startsWith("00000000")) bots.add(p.getUuid());
        }
    }

    public boolean isBot(UUID u) { return isEnabled() && bots.contains(u); }
}