package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import org.lwjgl.glfw.GLFW;

public final class SwordHotSwap extends Module {
    private final NumberSetting delay = new NumberSetting("Swap Delay", 0, 1000, 150, 25);
    private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
    private final TimerUtil timer = new TimerUtil();
    private int originalSlot = -1;

    public SwordHotSwap() { super("Sword Hotswap", "Swaps to shield when holding sword", Category.COMBAT); addSettings(delay, switchBack); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean rmb = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;

        if (rmb && mc.player.getMainHandStack().getItem() instanceof SwordItem && originalSlot == -1) {
            int shield = -1;
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.SHIELD) { shield = i; break; }
            if (shield != -1) { originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = shield; }
        } else if (!rmb && originalSlot != -1 && timer.hasElapsedTime(delay.getValueInt(), true)) {
            mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1;
        }
    }
}