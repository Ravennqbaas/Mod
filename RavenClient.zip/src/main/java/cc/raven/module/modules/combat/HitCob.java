package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.AttackEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class HitCob extends Module {
    public HitCob() { super("Hit Cob", "Places cobweb when hitting players", Category.COMBAT); }

    @EventTarget
    private void onAttack(AttackEvent event) {
        if (isNull() || !(event.getTarget() instanceof PlayerEntity target)) return;
        int webSlot = -1;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) { webSlot = i; break; }
        if (webSlot == -1) return;

        BlockPos feet = target.getBlockPos();
        if (!mc.world.getBlockState(feet).isAir()) return;
        if (mc.player.getPos().distanceTo(Vec3d.ofCenter(feet)) > 4.5) return;

        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = webSlot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(feet), Direction.UP, feet, false));
        mc.player.getInventory().selectedSlot = prev;
    }
}