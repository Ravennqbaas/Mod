package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import cc.raven.utils.mc.InventoryUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

public final class ShieldBreaker extends Module {
    private final NumberSetting cps = new NumberSetting("CPS", 1, 20, 20, 1);
    private final TimerUtil timer = new TimerUtil();
    private int savedSlot = -1;
    public static boolean breakingShield = false;

    public ShieldBreaker() { super("Shield Breaker", "Breaks enemy shields", Category.COMBAT); addSettings(cps); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof PlayerEntity target)) { breakingShield = false; return; }
        if (!target.isBlocking() || !target.isHolding(Items.SHIELD)) { breakingShield = false; return; }

        if (!(mc.player.getMainHandStack().getItem() instanceof AxeItem)) {
            if (savedSlot == -1) savedSlot = mc.player.getInventory().selectedSlot;
            InventoryUtil.swapToWeapon(AxeItem.class);
        }
        if (timer.hasElapsedTime((long)(1000.0 / cps.getValue()), true)) {
            ((MinecraftClientAccessor) mc).invokeDoAttack();
            breakingShield = true;
        }
    }

    @Override public void onDisable() { if (savedSlot != -1) { mc.player.getInventory().selectedSlot = savedSlot; savedSlot = -1; } breakingShield = false; super.onDisable(); }
}