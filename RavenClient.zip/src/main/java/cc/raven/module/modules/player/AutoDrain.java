package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public final class AutoDrain extends Module {
    private final NumberSetting cooldown = new NumberSetting("Cooldown", 50, 2000, 250, 1);
    private final TimerUtil timer = new TimerUtil();
    private int originalSlot = -1;
    private boolean pending;

    public AutoDrain() { super("Auto Drain", "Pick up water with bucket", Category.PLAYER); addSettings(cooldown); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (pending) { if (originalSlot != -1) mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1; pending = false; return; }
        if (!timer.hasElapsedTime(cooldown.getValueInt())) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr)) return;
        BlockPos pos = bhr.getBlockPos();
        if (mc.world.getFluidState(pos).getFluid() != Fluids.WATER || !mc.world.getFluidState(pos).isStill()) return;

        int bucket = -1;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.BUCKET) { bucket = i; break; }
        if (bucket == -1) return;
        originalSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = bucket;
        ((MinecraftClientAccessor) mc).invokeDoItemUse();
        pending = true; timer.reset();
    }
}