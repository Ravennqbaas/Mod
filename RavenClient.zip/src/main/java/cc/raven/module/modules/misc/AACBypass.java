package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.event.types.TransferOrder;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.ModeSetting;
import cc.raven.utils.math.MathUtils;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import java.security.SecureRandom;

public final class AACBypass extends Module {
    private final ModeSetting antiCheat = new ModeSetting("Anti-Cheat", "AAC", "AAC", "NCP", "Grim", "Intave", "Verus", "Vulcan", "Matrix", "Spartan", "Karhu", "Polar");
    private final SecureRandom random = new SecureRandom();
    private double lastX, lastY, lastZ;
    private float lastYaw, lastPitch;
    private long lastPacketTime;
    private int ticksExisted;
    private boolean isTeleporting;
    private int teleportTicks;

    public AACBypass() { super("AntiCheat Bypass", "Bypasses multiple anti-cheat systems", Category.MISC); addSettings(antiCheat); }

    @Override public void onEnable() { super.onEnable(); ticksExisted = 0; lastX = mc.player.getX(); lastY = mc.player.getY(); lastZ = mc.player.getZ(); lastYaw = mc.player.getYaw(); lastPitch = mc.player.getPitch(); lastPacketTime = System.currentTimeMillis(); }

    @EventTarget
    private void onPacketSend(PacketEvent event) {
        if (isNull() || event.getOrder() != TransferOrder.SEND) return;
        if (event.getPacket() instanceof PlayerMoveC2SPacket packet) {
            event.cancel();
            double x = packet.getX(mc.player.getX()), y = packet.getY(mc.player.getY()), z = packet.getZ(mc.player.getZ());
            float yaw = packet.getYaw(mc.player.getYaw()), pitch = packet.getPitch(mc.player.getPitch());
            boolean onGround = packet.isOnGround();

            if (antiCheat.isMode("AAC")) bypassAAC(x, y, z, yaw, pitch, onGround);
            else if (antiCheat.isMode("Grim")) bypassGrim(x, y, z, yaw, pitch, onGround);
            else if (antiCheat.isMode("Intave")) bypassIntave(x, y, z, yaw, pitch, onGround);
            else if (antiCheat.isMode("NCP")) bypassNCP(x, y, z, yaw, pitch, onGround);
            else sendDirect(x, y, z, yaw, pitch, onGround);
        }
    }

    @EventTarget
    private void onPacketReceive(PacketEvent event) {
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket) { isTeleporting = true; teleportTicks = 0; }
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        ticksExisted++;
        if (isTeleporting && ++teleportTicks > 2) isTeleporting = false;
    }

    private void bypassAAC(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        double speed = Math.sqrt((x - lastX) * (x - lastX) + (z - lastZ) * (z - lastZ));
        double maxSpeed = mc.player.isSprinting() ? 0.2873 : 0.216;
        if (speed > maxSpeed && !isTeleporting && !mc.player.isOnGround()) { x = lastX + (x - lastX) * (maxSpeed / speed); z = lastZ + (z - lastZ) * (maxSpeed / speed); }
        long now = System.currentTimeMillis();
        if (now - lastPacketTime < MathUtils.randomIntBetween(50, 150) && speed > 0.15) return;
        if (ticksExisted % 20 == 0) { x += (random.nextDouble() - 0.5) * 0.000001; z += (random.nextDouble() - 0.5) * 0.000001; }
        sendDirect(x, y, z, yaw, pitch, onGround);
    }

    private void bypassGrim(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        double dx = x - lastX, dz = z - lastZ;
        if (ticksExisted % 3 == 0 && Math.sqrt(dx*dx+dz*dz) > 0.001) { x += (random.nextDouble()-0.5)*Math.sqrt(dx*dx+dz*dz)*0.00001; z += (random.nextDouble()-0.5)*Math.sqrt(dx*dx+dz*dz)*0.00001; }
        if (!isTeleporting) { x = Math.round(x*1000000.0)/1000000.0; y = Math.round(y*1000000.0)/1000000.0; z = Math.round(z*1000000.0)/1000000.0; }
        sendDirect(x, y, z, yaw, pitch, onGround);
    }

    private void bypassIntave(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        if (ticksExisted % 5 == 0) { x += Math.sin(ticksExisted*0.1)*0.0000001; z += Math.cos(ticksExisted*0.1)*0.0000001; }
        sendDirect(x, y, z, yaw, pitch, onGround);
    }

    private void bypassNCP(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        double dx = x - lastX, dz = z - lastZ;
        if (Math.sqrt(dx*dx+dz*dz) > 0.28 && mc.player.isOnGround() && !isTeleporting) { x = lastX + dx*0.28/Math.sqrt(dx*dx+dz*dz); z = lastZ + dz*0.28/Math.sqrt(dx*dx+dz*dz); }
        if (y - lastY > 0.42 && !isTeleporting) y = lastY + 0.42;
        x += (random.nextDouble()-0.5)*0.000001; z += (random.nextDouble()-0.5)*0.000001;
        sendDirect(x, y, z, yaw, pitch, onGround);
    }

    private void sendDirect(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(x, y, z, yaw, pitch, onGround));
        lastX = x; lastY = y; lastZ = z; lastYaw = yaw; lastPitch = pitch; lastPacketTime = System.currentTimeMillis();
    }
}