package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;

public final class AutoExtinguish extends Module {
    private final BooleanSetting pickUp = new BooleanSetting("Pick up after", false);
    private final BooleanSetting rotateBack = new BooleanSetting("Rotate back", false);
    private final TimerUtil timer = new TimerUtil();
    private boolean extinguishing;
    private float originalPitch;
    private int originalSlot;

    public AutoExtinguish() { super("Auto Extinguish", "Auto water when on fire", Category.PLAYER); addSettings(pickUp, rotateBack); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (mc.player.isOnFire() && !extinguishing) {
            extinguishing = true; originalPitch = mc.player.getPitch(); originalSlot = mc.player.getInventory().selectedSlot;
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.WATER_BUCKET) { mc.player.getInventory().selectedSlot = i; break; }
            mc.player.setPitch(89.9f); ((MinecraftClientAccessor) mc).invokeDoItemUse(); timer.reset();
        }
        if (extinguishing && timer.hasElapsedTime(200)) {
            if (pickUp.getValue()) {
                for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.BUCKET) { mc.player.getInventory().selectedSlot = i; break; }
                ((MinecraftClientAccessor) mc).invokeDoItemUse();
            }
            if (rotateBack.getValue()) mc.player.setPitch(originalPitch);
            mc.player.getInventory().selectedSlot = originalSlot; extinguishing = false;
        }
    }
}