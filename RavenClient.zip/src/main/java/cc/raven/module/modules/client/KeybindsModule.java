package cc.raven.module.modules.client;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.ColorSetting;
import org.lwjgl.glfw.GLFW;
import java.awt.Color;

public class KeybindsModule extends Module {
    public static final ColorSetting bgColor = new ColorSetting("Background", new Color(18, 18, 22, 240));
    public static final ColorSetting keyColor = new ColorSetting("Key Color", new Color(35, 35, 40, 255));
    public static final ColorSetting assignedColor = new ColorSetting("Assigned Color", new Color(180, 40, 40, 255));

    public KeybindsModule() { super("Keybinds", "Visual keybind editor", GLFW.GLFW_KEY_K, Category.CLIENT); addSettings(bgColor, keyColor, assignedColor); }

    @Override public void onEnable() { if (mc.currentScreen == null) mc.setScreen(new cc.raven.gui.KeybindsScreen()); setEnabled(false); }
}