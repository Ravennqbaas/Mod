package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.Random;

public final class AutoRefill extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 10, 200, 50, 10);
    private final NumberSetting minStack = new NumberSetting("Min Stack", 1, 64, 16, 1);
    private final BooleanSetting health = new BooleanSetting("Health", true);
    private final BooleanSetting randomPick = new BooleanSetting("Random Pick", true);
    private final TimerUtil timer = new TimerUtil();
    private final Random rng = new Random();
    private boolean active;

    public AutoRefill() { super("Auto Refill", "Refill hotbar with potions", Category.PLAYER); addSettings(delay, minStack, health, randomPick); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.currentScreen instanceof InventoryScreen)) return;
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_R) == GLFW.GLFW_PRESS) {
            if (!active) { active = true; timer.reset(); }
            if (active && timer.hasElapsedTime(delay.getValueInt())) {
                if (needsRefill()) { int slot = findPotion(); if (slot != -1) { mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, 0, SlotActionType.QUICK_MOVE, mc.player); timer.reset(); } }
            }
        } else active = false;
    }

    private boolean needsRefill() {
        for (int i = 0; i < 9; i++) { var s = mc.player.getInventory().getStack(i); if (s.isEmpty() || (isPotion(s) && s.getCount() < minStack.getValueInt())) return true; }
        return false;
    }

    private int findPotion() {
        var pots = new ArrayList<Integer>();
        for (int i = 9; i < 36; i++) if (isPotion(mc.player.getInventory().getStack(i))) pots.add(i);
        return pots.isEmpty() ? -1 : pots.get(randomPick.getValue() ? rng.nextInt(pots.size()) : 0);
    }

    private boolean isPotion(net.minecraft.item.ItemStack s) {
        if (s.isEmpty()) return false;
        Item i = s.getItem();
        if (i != Items.POTION && i != Items.SPLASH_POTION) return false;
        var c = s.get(DataComponentTypes.POTION_CONTENTS);
        return c != null && c.potion().isPresent() && c.potion().get().value().getEffects().stream().anyMatch(e -> health.getValue() && e.getEffectType().equals(StatusEffects.INSTANT_HEALTH));
    }
}