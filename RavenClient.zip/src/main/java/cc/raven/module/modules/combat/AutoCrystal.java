package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import cc.raven.utils.mc.InventoryUtil;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;

public final class AutoCrystal extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 1, 200, 50, 1);
    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", true);
    private final TimerUtil timer = new TimerUtil();

    public AutoCrystal() {
        super("Auto Crystal", "Automatically places and breaks crystals", Category.COMBAT);
        addSettings(delay, autoSwitch);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.options.attackKey.isPressed() || !timer.hasElapsedTime(delay.getValueInt())) return;

        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity crystal && crystal.isAlive()) {
            ((MinecraftClientAccessor)mc).invokeDoAttack(); timer.reset(); return;
        }
        if (mc.crosshairTarget instanceof BlockHitResult bhr) {
            BlockPos pos = bhr.getBlockPos().offset(bhr.getSide());
            var block = mc.world.getBlockState(bhr.getBlockPos()).getBlock();
            if ((block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) && mc.world.getBlockState(pos).isAir() && mc.world.getBlockState(pos.up()).isAir()) {
                if (autoSwitch.getValue()) InventoryUtil.swapToSlot(Items.END_CRYSTAL);
                if (mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL) { ((MinecraftClientAccessor)mc).invokeDoItemUse(); timer.reset(); }
            }
        }
    }
}