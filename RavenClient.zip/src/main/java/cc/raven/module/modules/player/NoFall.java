package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.ModeSetting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public final class NoFall extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Packet", "Packet", "Ground");

    public NoFall() { super("NoFall", "Prevent fall damage", Category.PLAYER); addSettings(mode); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.player.fallDistance < 3) return;
        if (mode.getMode().equals("Packet")) { mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true)); mc.player.fallDistance = 0; }
        else mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
    }
}