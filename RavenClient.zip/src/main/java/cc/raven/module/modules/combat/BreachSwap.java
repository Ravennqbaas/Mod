package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.AttackEvent;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;

public final class BreachSwap extends Module {
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 10, 100, 30, 1);
    private final BooleanSetting onlyOnGround = new BooleanSetting("Only on ground", true);
    private int originalSlot = -1;
    private long switchTime = 0;

    public BreachSwap() {
        super("Breach Swap", "Switches to Breach mace when attacking", Category.COMBAT);
        addSettings(switchDelay, onlyOnGround);
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (isNull() || !(event.getTarget() instanceof LivingEntity)) return;
        if (onlyOnGround.getValue() && !mc.player.isOnGround()) return;

        int maceSlot = findBreachMace();
        if (maceSlot == -1) return;
        originalSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = maceSlot;
        ((MinecraftClientAccessor) mc).invokeDoAttack();
        switchTime = System.currentTimeMillis();
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (isNull() || originalSlot == -1) return;
        if (System.currentTimeMillis() - switchTime >= switchDelay.getValue()) {
            mc.player.getInventory().selectedSlot = originalSlot;
            originalSlot = -1;
        }
    }

    private int findBreachMace() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() instanceof MaceItem && hasBreach(s)) return i;
        }
        return -1;
    }

    private boolean hasBreach(ItemStack s) {
        var key = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of("minecraft", "breach"));
        return s.getEnchantments().getEnchantments().stream()
            .anyMatch(e -> e.getKey().getRegistryEntry().getKey().get().equals(key));
    }

    @Override public void onDisable() { if (originalSlot != -1) { mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1; } super.onDisable(); }
}