package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.network.packet.s2c.common.ResourcePackSendS2CPacket;

public final class TextureStealer extends Module {
    private int stolen;

    public TextureStealer() { super("Texture Stealer", "Steals server resource packs", Category.MISC); }

    @EventTarget
    private void onPacket(PacketEvent event) {
        if (isNull() || !(event.getPacket() instanceof ResourcePackSendS2CPacket pkt)) return;
        stolen++; ChatUtil.addChatMessage("§aPack found: §f" + pkt.url());
    }
}