package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;

public final class AntiCheatDetector extends Module {
    private final BooleanSetting notify = new BooleanSetting("Notify", true);
    private String detected = "Unknown";
    private boolean found;

    public AntiCheatDetector() { super("AntiCheat Detector", "Detects server anti-cheat", Category.MISC); addSettings(notify); }

    @EventTarget
    private void onPacket(PacketEvent event) {
        if (isNull() || !(event.getPacket() instanceof ChatMessageS2CPacket chat)) return;
        String msg = chat.body().getString().toLowerCase();
        if (msg.contains("unfair") || msg.contains("cheat")) {
            if (msg.contains("nocheatplus") || msg.contains("ncp")) detected = "NCP";
            else if (msg.contains("aac")) detected = "AAC";
            else if (msg.contains("grim")) detected = "Grim";
            else if (msg.contains("intave")) detected = "Intave";
            else if (msg.contains("verus")) detected = "Verus";
            else if (msg.contains("vulcan")) detected = "Vulcan";
            else if (msg.contains("matrix")) detected = "Matrix";
            else if (msg.contains("spartan")) detected = "Spartan";
            if (!found && notify.getValue()) { found = true; ChatUtil.addChatMessage("§cDetected: §f" + detected); }
        }
    }
}