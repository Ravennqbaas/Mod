package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;

public final class Freecam extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 10.0, 1.0, 0.1);
    private Vec3d position;
    private float yaw, pitch;
    private Perspective prevPerspective;

    public Freecam() { super("Freecam", "Free camera mode", Category.MISC); addSettings(speed); }

    @Override public void onEnable() { super.onEnable(); if (isNull()) { setEnabled(false); return; } position = mc.player.getPos(); yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); prevPerspective = mc.options.getPerspective(); mc.options.setPerspective(Perspective.FIRST_PERSON); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        Vec3d fwd = Vec3d.fromPolar(0, yaw), right = Vec3d.fromPolar(0, yaw + 90);
        double spd = speed.getValue() * 0.5;
        if (mc.options.sprintKey.isPressed()) spd *= 2;
        if (mc.options.forwardKey.isPressed()) position = position.add(fwd.multiply(spd));
        if (mc.options.backKey.isPressed()) position = position.subtract(fwd.multiply(spd));
        if (mc.options.rightKey.isPressed()) position = position.add(right.multiply(spd));
        if (mc.options.leftKey.isPressed()) position = position.subtract(right.multiply(spd));
        if (mc.options.jumpKey.isPressed()) position = position.add(0, spd, 0);
        if (mc.options.sneakKey.isPressed()) position = position.add(0, -spd, 0);
        mc.gameRenderer.getCamera().setPos(position.x, position.y, position.z);
    }

    public void updateRotation(double dy, double dp) { yaw += (float)dy; pitch = MathHelper.clamp(pitch + (float)dp, -90f, 90f); }

    @Override public void onDisable() { super.onDisable(); if (mc.options != null) mc.options.setPerspective(prevPerspective); }
}