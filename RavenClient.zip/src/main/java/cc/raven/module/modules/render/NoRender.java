package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import net.minecraft.entity.effect.StatusEffects;

public final class NoRender extends Module {
    private final BooleanSetting noBlindness = new BooleanSetting("No Blindness", true);
    private final BooleanSetting noNausea = new BooleanSetting("No Nausea", true);

    public NoRender() { super("NoRender", "Disables annoying effects", Category.RENDER); addSettings(noBlindness, noNausea); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (noBlindness.getValue() && mc.player.hasStatusEffect(StatusEffects.BLINDNESS)) mc.player.removeStatusEffect(StatusEffects.BLINDNESS);
        if (noNausea.getValue() && mc.player.hasStatusEffect(StatusEffects.NAUSEA)) mc.player.removeStatusEffect(StatusEffects.NAUSEA);
    }
}