package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.DoAttackEvent;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import org.lwjgl.glfw.GLFW;

public class STap extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 1, 500, 60, 1);
    private final NumberSetting chance = new NumberSetting("Chance %", 1, 100, 100, 1);
    private final BooleanSetting onlyGround = new BooleanSetting("Only on ground", true);
    private final TimerUtil timer = new TimerUtil();
    private boolean wasSprinting;

    public STap() { super("STap", "Automatically S-taps", Category.COMBAT); addSettings(delay, chance, onlyGround); }

    @EventTarget
    private void onAttack(DoAttackEvent event) {
        if (isNull() || mc.targetedEntity == null) return;
        if (onlyGround.getValue() && !mc.player.isOnGround()) return;
        if (Math.random() * 100 > chance.getValueFloat()) return;
        if (mc.player.isSprinting() && GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) {
            wasSprinting = true; mc.options.backKey.setPressed(true); timer.reset();
        }
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (wasSprinting && timer.hasElapsedTime(delay.getValueInt(), true)) { mc.options.backKey.setPressed(false); wasSprinting = false; }
    }
}