package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public final class ElytraHotSwap extends Module {
    private final NumberSetting swapDelay = new NumberSetting("Swap Delay", 50, 500, 150, 25);
    private final BooleanSetting toggleMode = new BooleanSetting("Toggle Mode", true);
    private final TimerUtil timer = new TimerUtil();
    private boolean keyWasPressed, elytraOn;

    public ElytraHotSwap() {
        super("Elytra HotSwap", "Quickly swap elytra and chestplate", Category.COMBAT);
        addSettings(swapDelay, toggleMode);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !timer.hasElapsedTime(swapDelay.getValueInt(), true)) return;
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_G) == GLFW.GLFW_PRESS;
        if (!pressed || keyWasPressed) { keyWasPressed = pressed; return; }
        keyWasPressed = true;

        if (!elytraOn) {
            int elytraSlot = -1;
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.ELYTRA) { elytraSlot = i; break; }
            if (elytraSlot != -1) {
                mc.interactionManager.pickFromInventory(elytraSlot);
                mc.interactionManager.pickFromInventory(38);
                elytraOn = true;
            }
        } else {
            int cpSlot = -1;
            for (int i = 0; i < 9; i++) {
                var it = mc.player.getInventory().getStack(i).getItem();
                if (it == Items.DIAMOND_CHESTPLATE || it == Items.NETHERITE_CHESTPLATE) { cpSlot = i; break; }
            }
            if (cpSlot != -1) {
                mc.interactionManager.pickFromInventory(cpSlot);
                mc.interactionManager.pickFromInventory(38);
            }
            elytraOn = false;
        }
    }
}