package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import java.util.Random;

public final class Anchor extends Module {
    private final NumberSetting clickDelay = new NumberSetting("Click Delay", 1, 200, 50, 5);
    private final BooleanSetting doubleAnchor = new BooleanSetting("Double Anchor", false);
    private final NumberSetting minGlow = new NumberSetting("Min Glowstone", 1, 5, 2, 1);
    private final NumberSetting maxGlow = new NumberSetting("Max Glowstone", 1, 5, 4, 1);
    private final BooleanSetting randomGlow = new BooleanSetting("Random Glowstone", true);
    private final BooleanSetting safeAnchor = new BooleanSetting("Safe Anchor", true);
    private final NumberSetting safeChance = new NumberSetting("Safe Chance %", 10, 100, 70, 10);
    private final NumberSetting safeDistance = new NumberSetting("Safe Distance", 2, 5, 3, 1);

    private final TimerUtil timer = new TimerUtil();
    private final Random random = new Random();
    private boolean active, doubleMode, safeMode, keyWasPressed;
    private int keyPressCount, step, anchorCount, glowCount, targetGlow, originalSlot;
    private BlockPos anchorPos, glowPos;

    public Anchor() {
        super("Anchor", "Legit anchor macro with safe anchor", Category.COMBAT);
        addSettings(clickDelay, doubleAnchor, minGlow, maxGlow, randomGlow, safeAnchor, safeChance, safeDistance);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean pressed = org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_KEY_X) == org.lwjgl.glfw.GLFW.GLFW_PRESS;

        if (pressed && !keyWasPressed) {
            keyPressCount++;
            if (keyPressCount == 1) new Thread(() -> {
                try { Thread.sleep(280); } catch (Exception ignored) {}
                doubleMode = keyPressCount >= 2 && doubleAnchor.getValue();
                safeMode = safeAnchor.getValue() && random.nextInt(100) < safeChance.getValueInt() && canSafe();
                start();
            }).start();
        }
        keyWasPressed = pressed;
        if (active && timer.hasElapsedTime(clickDelay.getValueInt(), true)) execute();
    }

    private boolean canSafe() {
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr)) return false;
        BlockPos place = bhr.getBlockPos().offset(bhr.getSide());
        if (!mc.world.getBlockState(place).isAir() && !mc.world.getBlockState(place).isReplaceable()) return false;
        if (mc.player.getPos().distanceTo(Vec3d.ofCenter(place)) < safeDistance.getValue()) return false;
        Direction facing = Direction.getEntityFacing(mc.player);
        BlockPos gPos = place.offset(facing.getOpposite());
        return mc.world.getBlockState(gPos).isAir() || mc.world.getBlockState(gPos).isReplaceable();
    }

    private void start() {
        active = true; step = 0; anchorCount = doubleMode ? 2 : 1; glowCount = 0;
        targetGlow = randomGlow.getValue() ? minGlow.getValueInt() + random.nextInt(maxGlow.getValueInt() - minGlow.getValueInt() + 1) : 1;
        timer.reset(); originalSlot = mc.player.getInventory().selectedSlot;
        if (mc.crosshairTarget instanceof BlockHitResult bhr) {
            BlockPos place = bhr.getBlockPos().offset(bhr.getSide());
            anchorPos = (mc.world.getBlockState(place).isAir() || mc.world.getBlockState(place).isReplaceable()) ? place : bhr.getBlockPos();
        }
    }

    private void execute() {
        if (anchorPos == null) { finish(); return; }
        if (safeMode) executeSafe(); else executeNormal();
    }

    private void executeNormal() {
        BlockState bs = mc.world.getBlockState(anchorPos);
        var block = bs.getBlock();
        int charges = block == Blocks.RESPAWN_ANCHOR ? bs.get(RespawnAnchorBlock.CHARGES) : 0;

        if (block != Blocks.RESPAWN_ANCHOR) { swap(Items.RESPAWN_ANCHOR); use(); return; }
        if (charges < RespawnAnchorBlock.MAX_CHARGES && glowCount < targetGlow) {
            swap(Items.GLOWSTONE); use(); glowCount++; timer.setElapsedTime(clickDelay.getValueInt() + random.nextInt(30)); return;
        }
        if (charges > 0) {
            swapSword(); ((MinecraftClientAccessor)mc).invokeDoAttack(); anchorCount--;
            if (anchorCount > 0) { swap(Items.RESPAWN_ANCHOR); use(); glowCount = 0; targetGlow = randomGlow.getValue() ? minGlow.getValueInt() + random.nextInt(maxGlow.getValueInt() - minGlow.getValueInt() + 1) : 1; }
            else finish();
        } else finish();
    }

    private void executeSafe() {
        switch (step) {
            case 0 -> {
                Direction f = Direction.getEntityFacing(mc.player);
                glowPos = anchorPos.offset(f.getOpposite());
                if (!mc.world.getBlockState(glowPos).isAir() && !mc.world.getBlockState(glowPos).isReplaceable()) { safeMode = false; return; }
                swap(Items.GLOWSTONE); lookAt(Vec3d.ofCenter(glowPos)); use(); step = 1;
            }
            case 1 -> {
                if (!mc.world.getBlockState(anchorPos).isAir() && !mc.world.getBlockState(anchorPos).isReplaceable()) { finish(); return; }
                swap(Items.RESPAWN_ANCHOR); lookAt(Vec3d.ofCenter(anchorPos)); use(); step = 2;
            }
            case 2 -> {
                BlockState bs = mc.world.getBlockState(anchorPos);
                if (bs.getBlock() == Blocks.RESPAWN_ANCHOR && bs.get(RespawnAnchorBlock.CHARGES) < RespawnAnchorBlock.MAX_CHARGES && glowCount < targetGlow) {
                    swap(Items.GLOWSTONE); lookAt(Vec3d.ofCenter(glowPos)); use(); glowCount++; timer.setElapsedTime(clickDelay.getValueInt() + random.nextInt(40));
                } else step = 3;
            }
            case 3 -> {
                BlockState bs = mc.world.getBlockState(anchorPos);
                if (bs.getBlock() == Blocks.RESPAWN_ANCHOR && bs.get(RespawnAnchorBlock.CHARGES) > 0) { swapSword(); lookAt(Vec3d.ofCenter(anchorPos)); ((MinecraftClientAccessor)mc).invokeDoAttack(); }
                finish();
            }
        }
    }

    private void use() { if (mc.crosshairTarget instanceof BlockHitResult) ((MinecraftClientAccessor)mc).invokeDoItemUse(); }
    private void lookAt(Vec3d t) {
        Vec3d d = t.subtract(mc.player.getEyePos());
        double dist = Math.sqrt(d.x*d.x+d.z*d.z);
        mc.player.setYaw((float)Math.toDegrees(Math.atan2(d.z,d.x))-90f+(random.nextFloat()-0.5f)*2f);
        mc.player.setPitch(Math.min(89,Math.max(-89,(float)-Math.toDegrees(Math.atan2(d.y,dist))+(random.nextFloat()-0.5f)*1f)));
    }
    private void swap(net.minecraft.item.Item item) { for (int i=0;i<9;i++) if(mc.player.getInventory().getStack(i).getItem()==item){mc.player.getInventory().selectedSlot=i;return;} }
    private void swapSword() { for (int i=0;i<9;i++){var it=mc.player.getInventory().getStack(i).getItem();if(it instanceof SwordItem||it==Items.AIR||it==Items.TOTEM_OF_UNDYING){mc.player.getInventory().selectedSlot=i;return;}} }
    private void finish() { if(originalSlot!=-1)mc.player.getInventory().selectedSlot=originalSlot; active=false;step=0;anchorPos=null;glowPos=null; }
    @Override public void onDisable() { super.onDisable(); finish(); }
}