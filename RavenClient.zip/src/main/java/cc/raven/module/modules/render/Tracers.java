package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.modules.misc.Teams;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.utils.friend.FriendManager;
import cc.raven.utils.render.RendererUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import java.awt.Color;

public final class Tracers extends Module {
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final ColorSetting color = new ColorSetting("Color", new Color(200, 50, 50, 180));
    private final ColorSetting friendColor = new ColorSetting("Friend Color", new Color(50, 200, 100, 180));

    public Tracers() { super("Tracers", "Draws lines to entities", Category.RENDER); addSettings(players, color, friendColor); }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull()) return;
        RendererUtils.setupRender(); RenderSystem.disableDepthTest();
        var matrices = event.getMatrixStack();
        var camera = mc.gameRenderer.getCamera().getPos();
        var buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        var matrix = matrices.peek().getPositionMatrix();
        Vec3d playerPos = mc.player.getEyePos().subtract(camera);

        for (Entity e : mc.world.getEntities()) {
            if (!isValid(e)) continue;
            Color c = (e instanceof PlayerEntity && FriendManager.isFriend(e.getUuid())) ? friendColor.getValue() : color.getValue();
            float r = c.getRed()/255f, g = c.getGreen()/255f, b = c.getBlue()/255f, a = c.getAlpha()/255f;
            Vec3d ep = e.getPos().add(0, e.getHeight()/2, 0).subtract(camera);
            buffer.vertex(matrix, (float)playerPos.x, (float)playerPos.y, (float)playerPos.z).color(r,g,b,a).next();
            buffer.vertex(matrix, (float)ep.x, (float)ep.y, (float)ep.z).color(r,g,b,a).next();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableDepthTest(); RendererUtils.endRender();
    }

    private boolean isValid(Entity e) {
        if (e == mc.player || e == mc.cameraEntity) return false;
        if (e instanceof PlayerEntity) { if (Teams.isTeammate(e)) return false; return players.getValue(); }
        return false;
    }
}