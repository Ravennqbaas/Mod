package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;

public final class Sprint extends Module {
    private final BooleanSetting omnidirectional = new BooleanSetting("Omnidirectional", true);

    public Sprint() { super("Sprint", "Auto sprint", Category.MOVEMENT); addSettings(omnidirectional); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.player.isOnGround() || mc.player.isSneaking() || mc.player.isUsingItem()) return;
        if (omnidirectional.getValue()) { if (isMoving()) mc.player.setSprinting(true); }
        else { if (mc.options.forwardKey.isPressed()) mc.player.setSprinting(true); }
    }

    private boolean isMoving() { return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed(); }
}