package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.AttackEvent;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.friend.FriendManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class StunCob extends Module {
    private final NumberSetting prediction = new NumberSetting("Prediction", 0.1, 2.0, 0.5, 0.1);
    private Entity lastHit;

    public StunCob() { super("Stun Cob", "Predictive cobweb placement", Category.COMBAT); addSettings(prediction); }

    @EventTarget private void onAttack(AttackEvent e) { lastHit = e.getTarget(); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || lastHit == null) return;
        Vec3d pred = lastHit.getPos().add(lastHit.getVelocity().multiply(prediction.getValue()));
        BlockPos bp = BlockPos.ofFloored(pred);
        if (!mc.world.getBlockState(bp).isAir()) { lastHit = null; return; }
        int webSlot = -1;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) { webSlot = i; break; }
        if (webSlot == -1) { lastHit = null; return; }
        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = webSlot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(bp), Direction.UP, bp, false));
        mc.player.getInventory().selectedSlot = prev;
        lastHit = null;
    }
}