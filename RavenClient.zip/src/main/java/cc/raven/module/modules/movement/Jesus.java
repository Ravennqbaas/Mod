package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.ModeSetting;

public final class Jesus extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Solid", "Solid", "Dolphin", "Boost");

    public Jesus() { super("Jesus", "Walk on water", Category.MOVEMENT); addSettings(mode); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.player.isTouchingWater() || mc.player.isSubmergedInWater()) return;
        switch (mode.getMode()) {
            case "Solid" -> mc.player.setOnGround(true);
            case "Dolphin" -> mc.player.jump();
            case "Boost" -> { if (!mc.player.isOnGround()) mc.player.setVelocity(mc.player.getVelocity().x, 0.1, mc.player.getVelocity().z); }
        }
    }
}