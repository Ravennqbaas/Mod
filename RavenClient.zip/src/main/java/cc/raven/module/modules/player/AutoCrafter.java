package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.client.gui.screen.ingame.CraftingScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import java.util.Arrays;
import java.util.List;

public final class AutoCrafter extends Module {
    private static final List<Recipe> RECIPES = Arrays.asList(
        new Recipe(Items.DIAMOND_SWORD, Items.DIAMOND, 2, Items.STICK, 1, new int[]{-1, 1, -1, -1, 1, -1, -1, 2, -1}),
        new Recipe(Items.DIAMOND_HELMET, Items.DIAMOND, 5, new int[]{1, 1, 1, 1, -1, 1, -1, -1, -1}),
        new Recipe(Items.DIAMOND_CHESTPLATE, Items.DIAMOND, 8, new int[]{1, -1, 1, 1, 1, 1, 1, 1, 1}),
        new Recipe(Items.GOLDEN_APPLE, Items.GOLD_INGOT, 8, Items.APPLE, 1, new int[]{1, 1, 1, 1, 2, 1, 1, 1, 1})
    );

    private final BooleanSetting swords = new BooleanSetting("Swords", true);
    private final BooleanSetting helmets = new BooleanSetting("Helmets", true);
    private final BooleanSetting chestplates = new BooleanSetting("Chestplates", true);
    private final BooleanSetting apples = new BooleanSetting("Golden Apples", true);
    private final NumberSetting delay = new NumberSetting("Delay", 0, 500, 100, 10);
    private final TimerUtil timer = new TimerUtil();
    private boolean crafting;

    public AutoCrafter() {
        super("Auto Crafter", "Auto craft in crafting table", Category.PLAYER);
        addSettings(swords, helmets, chestplates, apples, delay);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.currentScreen instanceof CraftingScreen) || !timer.hasElapsedTime(delay.getValueInt())) return;
        if (crafting) { collect(); return; }
        Recipe r = findRecipe();
        if (r != null) craft(r);
    }

    private Recipe findRecipe() {
        for (Recipe r : RECIPES) {
            if (r.result == Items.GOLDEN_APPLE && !apples.getValue()) continue;
            if (!isEnabled(r.result)) continue;
            if (getCount(r.material1) < r.count1) continue;
            if (r.material2 != null && getCount(r.material2) < r.count2) continue;
            if (hasItem(r.result)) continue;
            return r;
        }
        return null;
    }

    private boolean isEnabled(Item i) {
        if (i == Items.DIAMOND_SWORD) return swords.getValue();
        if (i == Items.DIAMOND_HELMET) return helmets.getValue();
        if (i == Items.DIAMOND_CHESTPLATE) return chestplates.getValue();
        if (i == Items.GOLDEN_APPLE) return apples.getValue();
        return false;
    }

    private void craft(Recipe r) {
        for (int i = 1; i <= 9; i++) if (!mc.player.currentScreenHandler.getSlot(i).getStack().isEmpty())
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
        for (int i = 0; i < r.pattern.length; i++) {
            int mt = r.pattern[i]; if (mt == -1) continue;
            Item mat = mt == 1 ? r.material1 : r.material2;
            int src = findSlot(mat);
            if (src != -1) {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, src, 1, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i + 1, 1, SlotActionType.PICKUP, mc.player);
            }
        }
        crafting = true; timer.reset();
    }

    private void collect() {
        if (!mc.player.currentScreenHandler.getSlot(0).getStack().isEmpty())
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 0, 0, SlotActionType.QUICK_MOVE, mc.player);
        crafting = false; timer.reset();
    }

    private int findSlot(Item item) {
        for (int i = 1; i < mc.player.currentScreenHandler.slots.size(); i++)
            if (mc.player.currentScreenHandler.getSlot(i).getStack().getItem() == item) return i;
        return -1;
    }

    private int getCount(Item item) {
        int c = 0;
        for (int i = 0; i < 36; i++) { var s = mc.player.getInventory().getStack(i); if (!s.isEmpty() && s.getItem() == item) c += s.getCount(); }
        return c;
    }

    private boolean hasItem(Item item) { return getCount(item) > 0; }

    private record Recipe(Item result, Item material1, int count1, Item material2, int count2, int[] pattern) {
        Recipe(Item result, Item material1, int count1, int[] pattern) { this(result, material1, count1, null, 0, pattern); }
    }
}