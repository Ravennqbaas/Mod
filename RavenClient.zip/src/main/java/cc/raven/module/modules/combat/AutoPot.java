package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;

public final class AutoPot extends Module {
    private final NumberSetting health = new NumberSetting("Health", 1, 20, 10, 0.5);
    private final NumberSetting delay = new NumberSetting("Delay", 50, 1000, 250, 50);
    private final TimerUtil timer = new TimerUtil();

    public AutoPot() {
        super("Auto Pot", "Throws health potions when low", Category.COMBAT);
        addSettings(health, delay);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.player.getHealth() > health.getValueFloat() || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem() == Items.SPLASH_POTION) {
                var c = s.get(DataComponentTypes.POTION_CONTENTS);
                if (c != null && c.potion().isPresent() && c.potion().get().value().getEffects().stream().anyMatch(e -> e.getEffectType().equals(StatusEffects.INSTANT_HEALTH))) { slot = i; break; }
            }
        }
        if (slot == -1) return;
        int prev = mc.player.getInventory().selectedSlot;
        float pp = mc.player.getPitch();
        mc.player.getInventory().selectedSlot = slot;
        mc.player.setPitch(-89.9f);
        ((MinecraftClientAccessor)mc).invokeDoItemUse();
        mc.player.getInventory().selectedSlot = prev;
        mc.player.setPitch(pp);
    }
}