package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public final class PearlCatch extends Module {
    private final NumberSetting windDelay = new NumberSetting("Wind Delay", 0, 2000, 200, 1);
    private final TimerUtil timer = new TimerUtil();
    private boolean thrown;
    private int originalSlot;

    public PearlCatch() { super("Pearl Catch", "Pearl + wind charge combo", Category.MISC); addSettings(windDelay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_H) == GLFW.GLFW_PRESS && !thrown) { throwPearl(); }
        if (thrown && timer.hasElapsedTime(windDelay.getValueInt())) {
            int ws = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.WIND_CHARGE) { ws = i; break; }
            if (ws != -1) { originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = ws; ((MinecraftClientAccessor)mc).invokeDoItemUse(); }
            thrown = false;
        }
    }

    private void throwPearl() {
        int ps = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.ENDER_PEARL) { ps = i; break; }
        if (ps == -1 || mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())) return;
        originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = ps;
        ((MinecraftClientAccessor)mc).invokeDoItemUse(); thrown = true; timer.reset();
    }
}