package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;

public final class Step extends Module {
    private final NumberSetting height = new NumberSetting("Height", 1.0, 5.0, 1.5, 0.5);

    public Step() { super("Step", "Auto step up blocks", Category.MOVEMENT); addSettings(height); }

    @EventTarget
    private void onTick(TickEvent event) { if (!isNull()) mc.player.stepHeight = height.getValueFloat(); }

    @Override public void onDisable() { super.onDisable(); if (mc.player != null) mc.player.stepHeight = 0.6f; }
}