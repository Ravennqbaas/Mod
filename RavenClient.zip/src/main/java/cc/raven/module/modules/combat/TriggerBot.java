package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.modules.misc.Teams;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ModeSetting;
import cc.raven.module.setting.RangeSetting;
import cc.raven.utils.friend.FriendManager;
import cc.raven.utils.math.MathUtils;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;

public final class TriggerBot extends Module {
    private final RangeSetting reaction = new RangeSetting("Reaction", 1, 350, 20, 95, 0.5);
    private final ModeSetting cooldown = new ModeSetting("Cooldown", "Smart", "Smart", "Strict", "None");
    private final BooleanSetting noPassive = new BooleanSetting("No Passive", true);
    private final TimerUtil timer = new TimerUtil();
    private boolean waiting;
    private long currentReaction;

    public TriggerBot() { super("Trigger Bot", "Automatically attacks targets", Category.COMBAT); addSettings(reaction, cooldown, noPassive); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.player.isUsingItem()) return;
        if (!(mc.targetedEntity instanceof LivingEntity target) || !target.isAlive()) return;
        if (noPassive.getValue() && target instanceof PassiveEntity) return;
        if (Teams.isTeammate(target)) return;
        if (target instanceof PlayerEntity p && FriendManager.isFriend(p.getUuid())) return;

        if (!waiting) { waiting = true; currentReaction = (long) MathUtils.randomDoubleBetween(reaction.getMinValue(), reaction.getMaxValue()); timer.reset(); }
        if (waiting && timer.hasElapsedTime(currentReaction)) {
            float cd = mc.player.getAttackCooldownProgress(0f);
            boolean can = switch (cooldown.getMode()) { case "Smart" -> cd >= 0.9f; case "Strict" -> cd >= 1.0f; default -> true; };
            if (can) { ((MinecraftClientAccessor)mc).invokeDoAttack(); waiting = false; }
        }
    }
}