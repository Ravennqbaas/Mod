package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

public final class ElytraFly extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 0.1, 5.0, 1.5, 0.1);
    private final NumberSetting upSpeed = new NumberSetting("Up Speed", 0.1, 3.0, 1.0, 0.1);
    private final NumberSetting downSpeed = new NumberSetting("Down Speed", 0.1, 3.0, 1.0, 0.1);

    public ElytraFly() {
        super("Elytra Fly", "Better elytra control", Category.MOVEMENT);
        addSettings(speed, upSpeed, downSpeed);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() != Items.ELYTRA || !mc.player.isFallFlying()) return;
        Vec3d vel = mc.player.getVelocity();
        if (mc.options.jumpKey.isPressed()) mc.player.setVelocity(vel.x, upSpeed.getValue(), vel.z);
        else if (mc.options.sneakKey.isPressed()) mc.player.setVelocity(vel.x, -downSpeed.getValue(), vel.z);
        if (mc.options.forwardKey.isPressed()) mc.player.setVelocity(mc.player.getVelocity().add(Vec3d.fromPolar(0, mc.player.getYaw()).multiply(speed.getValue() * 0.1)));
    }
}