package cc.raven.module.modules.misc;

import cc.raven.RavenClient;
import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class Teams extends Module {
    public Teams() { super("Teams", "Avoid targeting teammates", Category.MISC); }

    public static boolean isTeammate(Entity e) {
        var tm = RavenClient.INSTANCE.getModuleManager().getModule(Teams.class);
        if (tm.isEmpty() || !tm.get().isEnabled()) return false;
        if (e == null || !(e instanceof LivingEntity)) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.getScoreboardTeam() == null) return false;
        return mc.player.isTeammate(e);
    }
}