package cc.raven.module.modules.render;

import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class CosmeticManager extends Module {
    public static final Path COSMETICS_DIR = Paths.get(net.minecraft.client.MinecraftClient.getInstance().runDirectory.getPath(), "RavenClient/cosmetics");
    private static String activeCape = "none", activeSkin = "none", activeHat = "none";
    private static final Map<String, Identifier> loadedTextures = new HashMap<>();

    public CosmeticManager() { super("Cosmetics", "Custom cape, skin and hat manager", Category.RENDER); }

    @Override public void onEnable() { if (mc.player != null) mc.setScreen(new CosmeticScreen()); setEnabled(false); }

    public static String getActiveCape() { return activeCape; }
    public static String getActiveSkin() { return activeSkin; }
    public static String getActiveHat() { return activeHat; }
    public static void setActiveCape(String c) { activeCape = c; saveConfig(); }
    public static void setActiveSkin(String s) { activeSkin = s; saveConfig(); }
    public static void setActiveHat(String h) { activeHat = h; saveConfig(); }

    public static Identifier getTexture(String name) {
        if (name.equals("none")) return null;
        if (loadedTextures.containsKey(name)) return loadedTextures.get(name);
        try {
            Path file = COSMETICS_DIR.resolve(name + ".png");
            if (Files.exists(file)) { Identifier id = Identifier.of("ravenclient", "cosmetics/" + name); loadedTextures.put(name, id); return id; }
        } catch (Exception ignored) {}
        return null;
    }

    private static void saveConfig() {
        try {
            Files.createDirectories(COSMETICS_DIR);
            Properties props = new Properties();
            props.setProperty("cape", activeCape); props.setProperty("skin", activeSkin); props.setProperty("hat", activeHat);
            props.store(Files.newOutputStream(COSMETICS_DIR.resolve("config.properties")), "Raven Cosmetics");
        } catch (Exception ignored) {}
    }

    public static void loadConfig() {
        try {
            Path cf = COSMETICS_DIR.resolve("config.properties");
            if (Files.exists(cf)) { Properties p = new Properties(); p.load(Files.newInputStream(cf)); activeCape = p.getProperty("cape", "none"); activeSkin = p.getProperty("skin", "none"); activeHat = p.getProperty("hat", "none"); }
        } catch (Exception ignored) {}
    }

    public static List<String> getAvailable(String type) {
        List<String> list = new ArrayList<>(); list.add("none");
        try { Files.createDirectories(COSMETICS_DIR); Files.list(COSMETICS_DIR).filter(p -> p.toString().endsWith(".png")).forEach(p -> { String n = p.getFileName().toString().replace(".png", ""); if (n.startsWith(type + "_")) list.add(n.replace(type + "_", "")); }); } catch (Exception ignored) {}
        return list;
    }

    public static class CosmeticScreen extends Screen {
        private TextFieldWidget nameField, urlField;
        private String status = "";

        protected CosmeticScreen() { super(Text.literal("Raven - Cosmetics")); }

        @Override protected void init() {
            int cx = width / 2, y = 35;
            nameField = new TextFieldWidget(textRenderer, cx - 150, y, 140, 18, Text.literal("Name"));
            urlField = new TextFieldWidget(textRenderer, cx - 150, y + 22, 300, 18, Text.literal("URL"));
            addDrawableChild(nameField); addDrawableChild(urlField);

            addDrawableChild(ButtonWidget.builder(Text.literal("Download Cape"), btn -> download("cape")).dimensions(cx - 150, y + 44, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Select Cape"), btn -> cycle("cape")).dimensions(cx - 50, y + 44, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Download Skin"), btn -> download("skin")).dimensions(cx - 150, y + 70, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Select Skin"), btn -> cycle("skin")).dimensions(cx - 50, y + 70, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Download Hat"), btn -> download("hat")).dimensions(cx - 150, y + 96, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Select Hat"), btn -> cycle("hat")).dimensions(cx - 50, y + 96, 95, 18).build());
        }

        private void download(String type) {
            String name = nameField.getText().trim(), url = urlField.getText().trim();
            if (name.isEmpty() || url.isEmpty()) { status = "§cName and URL required!"; return; }
            try { Files.createDirectories(COSMETICS_DIR); Files.copy(new java.net.URL(url).openStream(), COSMETICS_DIR.resolve(type + "_" + name + ".png"), StandardCopyOption.REPLACE_EXISTING); status = "§aDownloaded: " + name; } catch (Exception e) { status = "§cDownload failed!"; }
        }

        private void cycle(String type) {
            List<String> list = getAvailable(type);
            String current = type.equals("cape") ? activeCape : type.equals("skin") ? activeSkin : activeHat;
            int idx = list.indexOf(current); idx = (idx + 1) % list.size();
            if (type.equals("cape")) setActiveCape(list.get(idx)); else if (type.equals("skin")) setActiveSkin(list.get(idx)); else setActiveHat(list.get(idx));
            status = type + ": " + list.get(idx);
        }

        @Override public void render(DrawContext ctx, int mx, int my, float d) {
            renderBackground(ctx, mx, my, d);
            ctx.drawCenteredTextWithShadow(textRenderer, "Raven Cosmetics", width / 2, 10, 0xFF4444);
            if (!status.isEmpty()) ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, height - 20, status.contains("§c") ? 0xFF4444 : 0x44FF44);
            ctx.drawTextWithShadow(textRenderer, "Cape: " + activeCape + " | Skin: " + activeSkin + " | Hat: " + activeHat, 10, 5, 0xAAAAAA);
            super.render(ctx, mx, my, d);
        }
    }
}