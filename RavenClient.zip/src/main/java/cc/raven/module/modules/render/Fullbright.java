package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;

public final class Fullbright extends Module {
    private final NumberSetting gamma = new NumberSetting("Gamma", 1.0, 15.0, 10.0, 0.5);
    private double originalGamma;

    public Fullbright() { super("Fullbright", "Brightens the world", Category.RENDER); addSettings(gamma); }

    @Override public void onEnable() { super.onEnable(); originalGamma = mc.options.getGamma().getValue(); }

    @EventTarget
    private void onTick(TickEvent event) { if (!isNull()) mc.options.getGamma().setValue(gamma.getValue()); }

    @Override public void onDisable() { super.onDisable(); if (mc.options != null) mc.options.getGamma().setValue(originalGamma); }
}