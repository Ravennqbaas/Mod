package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import java.util.ArrayList;
import java.util.List;

public final class StashFinder extends Module {
    private final NumberSetting range = new NumberSetting("Range", 8, 256, 128, 8);
    private final NumberSetting minContainers = new NumberSetting("Min Containers", 1, 50, 8, 1);
    private final NumberSetting delay = new NumberSetting("Scan Delay", 1000, 30000, 5000, 1000);
    private final TimerUtil timer = new TimerUtil();

    public StashFinder() { super("Stash Finder", "Finds container stashes", Category.MISC); addSettings(range, minContainers, delay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        int r = range.getValueInt();
        BlockPos center = mc.player.getBlockPos();
        List<BlockPos> containers = new ArrayList<>();
        for (int x = -r; x <= r; x++) for (int y = -20; y <= 20; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = center.add(x, y, z);
            var b = mc.world.getBlockState(pos).getBlock();
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL || b.toString().contains("shulker_box")) containers.add(pos);
        }
        if (containers.size() >= minContainers.getValueInt()) { BlockPos f = containers.get(0); ChatUtil.addChatMessage("§6Stash! §f" + containers.size() + " at " + f.getX() + "," + f.getY() + "," + f.getZ()); }
    }
}