package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

public final class PingSpoof extends Module {
    private final NumberSetting msDelay = new NumberSetting("Ms", 1, 500, 60, 1);

    public PingSpoof() { super("Ping Spoof", "Increase your ping", Category.PLAYER); addSetting(msDelay); }

    @EventTarget
    private void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof KeepAliveS2CPacket packet && !isNull()) {
            CompletableFuture.runAsync(() -> {
                try { Thread.sleep(msDelay.getValueInt()); Objects.requireNonNull(mc.getNetworkHandler()).getConnection().send(new KeepAliveC2SPacket(packet.getId())); }
                catch (InterruptedException ignored) {}
            });
        }
    }
}