package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;

public final class Spammer extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 1000, 30000, 5000, 500);
    private final TimerUtil timer = new TimerUtil();
    private int index;
    private static final String[] MSGS = {"Raven Client on top!", "Kuzgun kanatlarıyla uçuyorum!"};

    public Spammer() { super("Spammer", "Spams messages in chat", Category.MISC); addSettings(delay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        mc.player.networkHandler.sendChatMessage(MSGS[index % MSGS.length]); index++;
    }
}