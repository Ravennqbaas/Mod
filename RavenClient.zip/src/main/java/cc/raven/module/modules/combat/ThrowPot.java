package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;

public final class ThrowPot extends Module {
    private final NumberSetting health = new NumberSetting("Health", 1, 20, 10, 0.5);
    private final NumberSetting potDelay = new NumberSetting("Pot Delay", 50, 500, 150, 25);
    private final BooleanSetting multi = new BooleanSetting("Multi Throw", true);
    private final TimerUtil timer = new TimerUtil();
    private final ArrayList<Integer> slots = new ArrayList<>();
    private int thrown, toThrow, originalSlot;
    private float originalPitch;

    public ThrowPot() { super("Throw Pot", "Throws multiple health potions", Category.COMBAT); addSettings(health, potDelay, multi); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_G) == GLFW.GLFW_PRESS;
        if (!pressed || mc.player.getHealth() > health.getValueFloat()) return;
        if (!timer.hasElapsedTime(potDelay.getValueInt(), true)) return;

        slots.clear();
        for (int i = 0; i < 9; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem() == Items.SPLASH_POTION) {
                var c = s.get(DataComponentTypes.POTION_CONTENTS);
                if (c != null && c.potion().isPresent() && c.potion().get().value().getEffects().stream().anyMatch(e -> e.getEffectType().equals(StatusEffects.INSTANT_HEALTH))) slots.add(i);
            }
        }
        if (slots.isEmpty()) return;

        originalSlot = mc.player.getInventory().selectedSlot;
        originalPitch = mc.player.getPitch();
        toThrow = multi.getValue() ? Math.min(3, slots.size()) : 1;

        mc.player.getInventory().selectedSlot = slots.get(thrown);
        mc.player.setPitch(-89.9f);
        ((MinecraftClientAccessor) mc).invokeDoItemUse();
        thrown++;
        if (thrown >= toThrow) {
            mc.player.getInventory().selectedSlot = originalSlot;
            mc.player.setPitch(originalPitch);
            thrown = 0;
        }
    }
}