package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import org.lwjgl.glfw.GLFW;

public final class KeyLava extends Module {
    private int tickCounter, originalSlot = -1;

    public KeyLava() { super("Key Lava", "Places and picks up lava quickly", Category.COMBAT); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.crosshairTarget instanceof BlockHitResult)) return;
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_L) == GLFW.GLFW_PRESS;
        if (!pressed) { tickCounter = 0; return; }

        if (tickCounter == 0) {
            originalSlot = mc.player.getInventory().selectedSlot;
            swap(Items.LAVA_BUCKET);
            ((MinecraftClientAccessor) mc).invokeDoItemUse();
            tickCounter++;
        } else if (tickCounter == 1) {
            ((MinecraftClientAccessor) mc).invokeDoItemUse();
            mc.player.getInventory().selectedSlot = originalSlot;
            tickCounter = 0;
        }
    }

    private void swap(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == item) { mc.player.getInventory().selectedSlot = i; return; }
    }
}