package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;

public final class Velocity extends Module {
    private final NumberSetting chance = new NumberSetting("Chance %", 1, 100, 100, 1);
    private final BooleanSetting noBackwards = new BooleanSetting("Ignore S press", true);

    public Velocity() { super("Velocity", "Reduces knockback with jump reset", Category.COMBAT); addSettings(chance, noBackwards); }

    @EventTarget
    private void onPacket(PacketEvent event) {
        if (isNull()) return;
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket pkt && pkt.getEntityId() == mc.player.getId()) {
            if (Math.random() * 100 > chance.getValueFloat()) return;
            if (noBackwards.getValue() && mc.options.backKey.isPressed()) return;
            if (mc.currentScreen != null) return;
            if (mc.player.isOnGround()) mc.player.jump();
        }
    }
}