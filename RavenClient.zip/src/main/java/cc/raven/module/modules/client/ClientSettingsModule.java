package cc.raven.module.modules.client;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.module.setting.ModeSetting;
import cc.raven.module.setting.NumberSetting;
import java.awt.Color;

public class ClientSettingsModule extends Module {
    public static final ColorSetting accentColor = new ColorSetting("Accent Color", new Color(180, 40, 40, 255));
    public static final ModeSetting fontStyle = new ModeSetting("Font", "Inter.ttf", "Inter.ttf", "jetbrainsmono.ttf", "poppins-medium.ttf", "Monaco.ttf");
    public static final BooleanSetting scrollableCategories = new BooleanSetting("Scrollable Categories", false);
    public static final NumberSetting guiScale = new NumberSetting("GUI Scale", 0.5, 3.0, 1.0, 0.1);
    public static final NumberSetting guiTransparency = new NumberSetting("GUI Transparency", 0, 100, 0, 1);
    public static final BooleanSetting guiBlur = new BooleanSetting("GUI Blur", false);
    public static final BooleanSetting moduleDescriptions = new BooleanSetting("Module Descriptions", true);
    public static final NumberSetting toggleWidth = new NumberSetting("Toggle Width", 10, 40, 20, 1);
    public static final NumberSetting toggleHeight = new NumberSetting("Toggle Height", 6, 20, 10, 1);
    public static final BooleanSetting guiGlow = new BooleanSetting("GUI Glow", false);
    public static final ColorSetting glowColor = new ColorSetting("Glow Color", new Color(180, 40, 40, 255));
    public static final BooleanSetting snowEffect = new BooleanSetting("Snow Effect", false);
    public static final BooleanSetting debugMode = new BooleanSetting("Debug Mode", false);

    public ClientSettingsModule() {
        super("Client Settings", "Customize GUI appearance", Category.CLIENT);
        this.addSettings(accentColor, fontStyle, scrollableCategories, guiScale, guiTransparency, guiBlur,
                moduleDescriptions, toggleWidth, toggleHeight, guiGlow, glowColor, snowEffect, debugMode);
        this.setEnabled(true);
    }

    public static Color getAccentColor() { return accentColor.getValue(); }
    public static String getFontStyle() { return fontStyle.getMode(); }
    public static boolean isScrollable() { return scrollableCategories.getValue(); }
    public static float getGuiScale() { return guiScale.getValueFloat(); }
    public static float getGuiTransparency() { return guiTransparency.getValueFloat() / 100f; }
    public static boolean isGuiBlurEnabled() { return guiBlur.getValue(); }
    public static boolean isModuleDescriptionsEnabled() { return moduleDescriptions.getValue(); }
    public static float getToggleWidth() { return toggleWidth.getValueFloat(); }
    public static float getToggleHeight() { return toggleHeight.getValueFloat(); }
    public static boolean isGuiGlowEnabled() { return guiGlow.getValue(); }
    public static Color getGlowColor() { return glowColor.getValue(); }
    public static boolean isSnowEffectEnabled() { return snowEffect.getValue(); }
}