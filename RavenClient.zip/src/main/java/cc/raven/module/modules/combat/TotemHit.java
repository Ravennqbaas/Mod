package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TotemHit extends Module {
    private final NumberSetting delay = new NumberSetting("Switch Delay", 10, 100, 30, 1);
    private int originalSlot = -1;
    private long switchTime;
    private boolean lastAttack;

    public TotemHit() { super("Totem Hit", "Switches to sword when holding totem", Category.COMBAT); addSettings(delay); }

    @EventTarget
    public void onTick(TickEvent event) {
        if (isNull()) return;
        if (System.currentTimeMillis() - switchTime > delay.getValue() && originalSlot != -1) { mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1; }

        boolean attack = mc.options.attackKey.isPressed();
        if (attack && !lastAttack && mc.player.getMainHandStack().getItem() == Items.TOTEM_OF_UNDYING && mc.crosshairTarget instanceof EntityHitResult) {
            int sword = -1;
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() instanceof SwordItem) { sword = i; break; }
            if (sword != -1) { originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = sword; ((MinecraftClientAccessor)mc).invokeDoAttack(); switchTime = System.currentTimeMillis(); }
        }
        lastAttack = attack;
    }
}