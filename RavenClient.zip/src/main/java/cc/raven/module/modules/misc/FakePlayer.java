package cc.raven.module.modules.misc;

import cc.raven.module.Category;
import cc.raven.module.Module;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.player.PlayerEntity;
import java.util.UUID;

public final class FakePlayer extends Module {
    private PlayerEntity fakePlayer;

    public FakePlayer() { super("Fake Player", "Spawns a fake player", Category.MISC); }

    @Override public void onEnable() {
        super.onEnable();
        if (isNull()) { setEnabled(false); return; }
        fakePlayer = new PlayerEntity(mc.world, mc.player.getBlockPos(), mc.player.getYaw(), new GameProfile(UUID.randomUUID(), "RavenBot")) {};
        fakePlayer.copyFrom(mc.player);
        mc.world.addEntity(fakePlayer.getId(), fakePlayer);
    }

    @Override public void onDisable() {
        super.onDisable();
        if (fakePlayer != null && mc.world != null) { mc.world.removeEntity(fakePlayer.getId(), net.minecraft.entity.Entity.RemovalReason.DISCARDED); fakePlayer = null; }
    }
}