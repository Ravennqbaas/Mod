package cc.raven.module.modules.client;

import cc.raven.gui.RavenClickGUI;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.KeybindSetting;
import org.lwjgl.glfw.GLFW;

public final class ClickGUIModule extends Module {
    private final KeybindSetting guiKey = new KeybindSetting("GUI Key", GLFW.GLFW_KEY_RIGHT_SHIFT, false);

    public ClickGUIModule() { super("Click Gui", "Toggles the Raven GUI", Category.CLIENT); addSettings(guiKey); }

    @Override public void onEnable() { if (mc.currentScreen == null) mc.setScreen(new RavenClickGUI()); setEnabled(false); }
    @Override public int getKey() { return guiKey.getKeyCode(); }
    @Override public void setKey(int key) { guiKey.setKeyCode(key); }
}