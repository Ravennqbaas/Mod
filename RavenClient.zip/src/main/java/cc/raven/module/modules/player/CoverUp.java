package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.item.Items;

public class CoverUp extends Module {
    private final NumberSetting delay = new NumberSetting("Place Delay", 0, 100, 20, 5);
    private int step, savedSlot;
    private float savedYaw, savedPitch;
    private long lastPlace;

    public CoverUp() { super("Cover Up", "Rotate down, place 2 cobwebs, rotate back", Category.PLAYER); addSettings(delay); }

    @Override public void onEnable() {
        if (isNull()) { setEnabled(false); return; }
        int ws = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) { ws = i; break; }
        if (ws == -1) { setEnabled(false); return; }
        savedSlot = mc.player.getInventory().selectedSlot; savedYaw = mc.player.getYaw(); savedPitch = mc.player.getPitch();
        mc.player.getInventory().selectedSlot = ws; step = 0; lastPlace = System.currentTimeMillis(); mc.player.setPitch(89.5f);
        super.onEnable();
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || System.currentTimeMillis() - lastPlace < delay.getValue()) return;
        if (step < 2) { ((MinecraftClientAccessor) mc).invokeDoItemUse(); step++; lastPlace = System.currentTimeMillis(); }
        else { mc.player.getInventory().selectedSlot = savedSlot; mc.player.setYaw(savedYaw); mc.player.setPitch(savedPitch); setEnabled(false); }
    }
}