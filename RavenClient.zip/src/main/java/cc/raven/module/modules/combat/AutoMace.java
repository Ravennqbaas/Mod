package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import cc.raven.utils.mc.InventoryUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;

public final class AutoMace extends Module {
    private final NumberSetting minFall = new NumberSetting("Min Fall Distance", 1.0, 10.0, 3.0, 0.5);
    private final NumberSetting delay = new NumberSetting("Attack Delay", 0, 500, 100, 10);
    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", true);
    private final TimerUtil timer = new TimerUtil();
    private double fallStart = -1;

    public AutoMace() {
        super("Auto Mace", "Automatically attacks with mace while falling", Category.COMBAT);
        addSettings(minFall, delay, autoSwitch);
    }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (!mc.player.isOnGround() && fallStart == -1) fallStart = mc.player.getY();
        if (mc.player.isOnGround()) { fallStart = -1; return; }
        if (fallStart - mc.player.getY() < minFall.getValue()) return;
        if (mc.targetedEntity instanceof LivingEntity && timer.hasElapsedTime(delay.getValueInt(), true)) {
            if (autoSwitch.getValue()) InventoryUtil.swapToSlot(Items.MACE);
            if (mc.player.getMainHandStack().getItem() == Items.MACE) ((MinecraftClientAccessor)mc).invokeDoAttack();
        }
    }
}