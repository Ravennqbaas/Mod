package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public final class AutoTool extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 0, 100, 5, 1);
    private final BooleanSetting returnPrev = new BooleanSetting("Return To Previous", true);
    private final TimerUtil timer = new TimerUtil();
    private int prevSlot = -1;

    public AutoTool() { super("Auto Tool", "Best tool auto switch", Category.PLAYER); addSettings(delay, returnPrev); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (!mc.options.attackKey.isPressed()) { if (returnPrev.getValue() && prevSlot != -1) { mc.player.getInventory().selectedSlot = prevSlot; prevSlot = -1; } return; }

        HitResult hit = mc.crosshairTarget;
        if (hit instanceof BlockHitResult bhr) {
            var state = mc.world.getBlockState(bhr.getBlockPos());
            int best = -1; float bestScore = 0;
            for (int i = 0; i < 9; i++) {
                var s = mc.player.getInventory().getStack(i);
                if (!s.isEmpty() && s.isSuitableFor(state)) {
                    float score = s.getMiningSpeedMultiplier(state);
                    if (s.getItem().toString().contains("netherite")) score *= 6;
                    else if (s.getItem().toString().contains("diamond")) score *= 5;
                    if (score > bestScore) { bestScore = score; best = i; }
                }
            }
            if (best != -1 && best != mc.player.getInventory().selectedSlot && timer.hasElapsedTime(delay.getValueInt())) {
                if (prevSlot == -1) prevSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = best; timer.reset();
            }
        }
    }
}