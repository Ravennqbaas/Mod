package cc.raven.module.modules.player;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;

public class FastMine extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 1, 10, 5, 0.5);
    public FastMine() { super("Fast Mine", "Mine blocks faster", Category.PLAYER); addSettings(speed); }
    public float getSpeed() { return speed.getValueFloat(); }
}