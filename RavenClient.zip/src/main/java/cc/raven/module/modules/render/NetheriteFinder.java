package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.render.RendererUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.*;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public final class NetheriteFinder extends Module {
    private final NumberSetting range = new NumberSetting("Range", 16, 256, 96, 16);
    private final BooleanSetting throughWalls = new BooleanSetting("Through Walls", true);
    private final BooleanSetting autoScan = new BooleanSetting("Auto Scan", true);
    private final ColorSetting color = new ColorSetting("Color", new Color(255, 100, 50, 200));
    private final Map<BlockPos, Boolean> foundBlocks = new ConcurrentHashMap<>();
    private final List<BlockPos> cachedBlocks = new ArrayList<>();
    private long lastScan;

    public NetheriteFinder() { super("Netherite Finder", "Scans Ancient Debris", Category.RENDER); addSettings(range, throughWalls, autoScan, color); }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull()) return;
        if (autoScan.getValue() && System.currentTimeMillis() - lastScan > 2000) { scan(); lastScan = System.currentTimeMillis(); }
        if (cachedBlocks.isEmpty()) return;

        RendererUtils.setupRender();
        if (throughWalls.getValue()) RenderSystem.disableDepthTest();
        var matrices = event.getMatrixStack();
        var camera = mc.gameRenderer.getCamera().getPos();
        var buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        var matrix = matrices.peek().getPositionMatrix();
        Color c = color.getValue();
        float r = c.getRed() / 255f, g = c.getGreen() / 255f, b = c.getBlue() / 255f, a = c.getAlpha() / 255f;

        for (BlockPos pos : cachedBlocks) {
            double dx = pos.getX() - camera.x, dy = pos.getY() - camera.y, dz = pos.getZ() - camera.z;
            float x1 = (float)dx, y1 = (float)dy, z1 = (float)dz, x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;
            buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x2, y1, z1).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x2, y1, z2).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x1, y1, z2).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x1, y2, z1).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x2, y2, z1).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a * 0.4f).next();
            buffer.vertex(matrix, x1, y2, z2).color(r, g, b, a * 0.4f).next();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        if (throughWalls.getValue()) RenderSystem.enableDepthTest();
        RendererUtils.endRender();
    }

    private void scan() {
        cachedBlocks.clear();
        int r = range.getValueInt();
        BlockPos center = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = center.add(x, y, z);
            if (mc.world.getBlockState(pos).getBlock() == Blocks.ANCIENT_DEBRIS && (!foundBlocks.containsKey(pos) || foundBlocks.get(pos))) cachedBlocks.add(pos);
        }
    }
}