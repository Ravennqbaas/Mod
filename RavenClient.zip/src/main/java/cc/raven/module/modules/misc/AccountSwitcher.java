package cc.raven.module.modules.misc;

import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public final class AccountSwitcher extends Module {
    private static final List<AltAccount> accounts = new ArrayList<>();

    public AccountSwitcher() { super("Account Switcher", "Switch between saved accounts", Category.MISC); }

    @Override public void onEnable() { if (mc.player != null) mc.setScreen(new AccountScreen()); setEnabled(false); }

    public static class AltAccount { public String name, email, password; public boolean cracked;
        public AltAccount(String name, String email, String password, boolean cracked) { this.name = name; this.email = email; this.password = password; this.cracked = cracked; }
    }

    private static class AccountScreen extends Screen {
        private TextFieldWidget nameField, passField;
        protected AccountScreen() { super(Text.literal("Raven - Accounts")); }

        @Override protected void init() {
            nameField = new TextFieldWidget(textRenderer, width/2-100, 60, 200, 18, Text.literal("Email/Name"));
            passField = new TextFieldWidget(textRenderer, width/2-100, 90, 200, 18, Text.literal("Password"));
            addDrawableChild(nameField); addDrawableChild(passField);
            addDrawableChild(ButtonWidget.builder(Text.literal("Add Account"), btn -> {
                String n = nameField.getText().trim(), p = passField.getText().trim();
                if (!n.isEmpty()) accounts.add(new AltAccount(n, n, p, p.isEmpty()));
            }).dimensions(width/2-100, 120, 200, 18).build());
            int y = 150;
            for (AltAccount a : accounts) { addDrawableChild(ButtonWidget.builder(Text.literal(a.name), btn -> {}).dimensions(width/2-100, y, 200, 18).build()); y += 22; }
        }

        @Override public void render(DrawContext ctx, int mx, int my, float d) { renderBackground(ctx, mx, my, d); ctx.drawCenteredTextWithShadow(textRenderer, "Raven Accounts", width/2, 20, 0xFF4444); super.render(ctx, mx, my, d); }
    }
}