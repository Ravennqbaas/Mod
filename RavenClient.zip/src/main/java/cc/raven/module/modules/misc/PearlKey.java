package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public final class PearlKey extends Module {
    private final NumberSetting delay = new NumberSetting("Throw Delay", 100, 5000, 1000, 50);
    private final TimerUtil timer = new TimerUtil();

    public PearlKey() { super("Pearl Key", "Auto pearl on key press", Category.MISC); addSettings(delay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_P) == GLFW.GLFW_PRESS && timer.hasElapsedTime(delay.getValueInt(), true)) {
            int ps = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.ENDER_PEARL) { ps = i; break; }
            if (ps == -1 || mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())) return;
            int prev = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = ps;
            ((MinecraftClientAccessor)mc).invokeDoItemUse(); mc.player.getInventory().selectedSlot = prev;
        }
    }
}