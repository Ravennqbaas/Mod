package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.slot.SlotActionType;

public final class ChestStealer extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 0, 200, 50, 10);
    private final BooleanSetting closeWhenDone = new BooleanSetting("Close When Done", true);
    private final TimerUtil timer = new TimerUtil();

    public ChestStealer() { super("Chest Stealer", "Auto loot chests", Category.PLAYER); addSettings(delay, closeWhenDone); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.currentScreen instanceof GenericContainerScreen) || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        var h = mc.player.currentScreenHandler;
        for (int i = 0; i < h.slots.size() - 36; i++) {
            if (!h.getSlot(i).getStack().isEmpty()) { mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player); return; }
        }
        if (closeWhenDone.getValue()) mc.player.closeHandledScreen();
    }
}