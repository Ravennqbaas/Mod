package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;

public final class RavenFlight extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 0.1, 10.0, 2.0, 0.1);
    private final BooleanSetting antiKick = new BooleanSetting("Anti Kick", true);
    private int ticks;

    public RavenFlight() { super("Raven Flight", "Free flight mode", Category.MOVEMENT); addSettings(speed, antiKick); }

    @Override public void onEnable() { super.onEnable(); ticks = 0; }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        mc.player.getAbilities().flying = true;
        mc.player.getAbilities().setFlySpeed((float)(speed.getValue() * 0.05f));

        if (antiKick.getValue()) { ticks++; if (ticks >= 20) { mc.player.setVelocity(mc.player.getVelocity().x, -0.04, mc.player.getVelocity().z); ticks = 0; } }

        Vec3d move = new Vec3d(0, 0, 0);
        if (mc.options.jumpKey.isPressed()) move = move.add(0, speed.getValue() * 0.3, 0);
        if (mc.options.sneakKey.isPressed()) move = move.add(0, -speed.getValue() * 0.3, 0);
        mc.player.setVelocity(mc.player.getVelocity().add(move));
    }

    @Override public void onDisable() {
        super.onDisable();
        if (mc.player != null) { mc.player.getAbilities().flying = false; mc.player.getAbilities().setFlySpeed(0.05f); }
    }
}