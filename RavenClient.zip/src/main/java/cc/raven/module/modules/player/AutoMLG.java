package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.mc.InventoryUtil;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

public final class AutoMLG extends Module {
    private final NumberSetting fallDist = new NumberSetting("Fall Distance", 3, 40, 8, 1);
    private final BooleanSetting pickUp = new BooleanSetting("Pick Up", true);
    private int stage, ticks, storedSlot = -1;
    private float storedPitch;

    public AutoMLG() { super("Auto MLG", "Auto water bucket clutch", Category.PLAYER); addSettings(fallDist, pickUp); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        if (stage == 0 && !mc.player.isOnGround() && !mc.player.isTouchingWater() && mc.player.fallDistance >= fallDist.getValue() && mc.player.getVelocity().y < -0.6 && InventoryUtil.hasItem(Items.WATER_BUCKET)) {
            storedSlot = mc.player.getInventory().selectedSlot; storedPitch = mc.player.getPitch(); InventoryUtil.swapToSlot(Items.WATER_BUCKET); stage = 1; ticks = 0;
        }
        if (stage == 1) {
            if (mc.player.isOnGround()) { stage = 3; return; }
            ticks++; if (findGround() > 2 || ticks % 2 != 0) return;
            mc.player.setPitch(89.5f); ((MinecraftClientAccessor) mc).invokeDoItemUse(); stage = pickUp.getValue() ? 2 : 3; ticks = 0;
        }
        if (stage == 2) { ticks++; if ((mc.player.isOnGround() || mc.player.isTouchingWater()) && ticks >= 3) { InventoryUtil.swapToSlot(Items.BUCKET); ((MinecraftClientAccessor) mc).invokeDoItemUse(); stage = 3; } }
        if (stage == 3) { if (storedSlot >= 0) mc.player.getInventory().selectedSlot = storedSlot; mc.player.setPitch(storedPitch); stage = 0; storedSlot = -1; }
    }

    private int findGround() { for (int i = 1; i <= 6; i++) if (!mc.world.getBlockState(mc.player.getBlockPos().down(i)).isAir()) return i; return 7; }
    @Override public void onDisable() { if (stage > 0 && storedSlot >= 0) mc.player.getInventory().selectedSlot = storedSlot; stage = 0; super.onDisable(); }
}