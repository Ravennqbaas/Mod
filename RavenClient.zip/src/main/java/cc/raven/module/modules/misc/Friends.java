package cc.raven.module.modules.misc;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.utils.friend.FriendManager;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;

public class Friends extends Module {
    public Friends() { super("Friends", "Manage friends list", Category.MISC); }

    @Override public void onEnable() { if (mc.player != null) mc.setScreen(new FriendsScreen()); setEnabled(false); }

    private static class FriendsScreen extends Screen {
        private TextFieldWidget nameField;
        protected FriendsScreen() { super(Text.literal("Raven - Friends")); }

        @Override protected void init() {
            nameField = new TextFieldWidget(textRenderer, width/2-100, 50, 200, 18, Text.literal("Player Name"));
            addDrawableChild(nameField);
            addDrawableChild(ButtonWidget.builder(Text.literal("Add Friend"), btn -> {
                String n = nameField.getText().trim();
                if (!n.isEmpty() && client.player != null) for (var p : client.world.getPlayers()) if (p.getName().getString().equalsIgnoreCase(n)) { FriendManager.addFriend(p.getUuid(), n); break; }
            }).dimensions(width/2-100, 80, 95, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Remove"), btn -> {
                String n = nameField.getText().trim();
                for (var u : FriendManager.getFriends()) if (FriendManager.getName(u).equalsIgnoreCase(n)) { FriendManager.removeFriend(u); break; }
            }).dimensions(width/2+5, 80, 95, 18).build());
            int y = 110;
            for (var u : FriendManager.getFriends()) { addDrawableChild(ButtonWidget.builder(Text.literal(FriendManager.getName(u)), btn -> {}).dimensions(width/2-100, y, 200, 18).build()); y += 22; }
        }

        @Override public void render(DrawContext ctx, int mx, int my, float d) { renderBackground(ctx, mx, my, d); ctx.drawCenteredTextWithShadow(textRenderer, "Raven Friends", width/2, 20, 0xFF4444); super.render(ctx, mx, my, d); }
    }
}