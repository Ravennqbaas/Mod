package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import java.security.SecureRandom;

public final class AutoWeb extends Module {
    private final NumberSetting count = new NumberSetting("Web Count", 1, 10, 3, 1);
    private final NumberSetting delay = new NumberSetting("Click Delay", 10, 200, 50, 10);
    private final BooleanSetting randomize = new BooleanSetting("Randomize Delay", true);
    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch Back", true);
    private final TimerUtil timer = new TimerUtil();
    private final SecureRandom rng = new SecureRandom();
    private boolean active;
    private int originalSlot, placed, target;

    public AutoWeb() { super("Auto Web", "Spam cobwebs", Category.PLAYER); addSettings(count, delay, randomize, autoSwitch); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_Z) == GLFW.GLFW_PRESS;
        if (pressed && !active) {
            int ws = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) { ws = i; break; }
            if (ws == -1) return;
            active = true; placed = 0; target = count.getValueInt(); originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = ws; timer.reset();
        } else if (!pressed && active) { stop(); }
        if (!active) return;
        long d = randomize.getValue() ? rng.nextLong(delay.getValueInt() / 2, delay.getValueInt() * 2) : delay.getValueInt();
        if (timer.hasElapsedTime(d) && placed < target) { ((MinecraftClientAccessor) mc).invokeDoItemUse(); placed++; timer.reset(); }
        else if (placed >= target) stop();
    }

    private void stop() { if (autoSwitch.getValue() && originalSlot != -1) mc.player.getInventory().selectedSlot = originalSlot; active = false; originalSlot = -1; }
}