package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;

public final class AutoDoubleHand extends Module {
    private final BooleanSetting inventorySwitch = new BooleanSetting("Inventory Switch", true);
    private final NumberSetting healthThreshold = new NumberSetting("Health Threshold", 1, 20, 15, 0.5);
    private int originalSlot = -1;

    public AutoDoubleHand() { super("Auto Double Hand", "Auto totem switch", Category.PLAYER); addSettings(inventorySwitch, healthThreshold); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull()) return;
        boolean needs = (inventorySwitch.getValue() && mc.currentScreen instanceof InventoryScreen) || mc.player.getHealth() <= healthThreshold.getValue();
        boolean has = mc.player.getMainHandStack().getItem() == Items.TOTEM_OF_UNDYING;
        if (needs && !has) switchTotem();
        else if (!needs && has && originalSlot != -1) { mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1; }
    }

    private void switchTotem() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
            originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = i; return;
        }
    }
}