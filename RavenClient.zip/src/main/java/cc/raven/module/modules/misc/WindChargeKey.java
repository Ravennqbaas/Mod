package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public final class WindChargeKey extends Module {
    private final NumberSetting delay = new NumberSetting("Throw Delay", 50, 1000, 200, 25);
    private final BooleanSetting autoJump = new BooleanSetting("Auto Jump", true);
    private final TimerUtil timer = new TimerUtil();

    public WindChargeKey() { super("Wind Charge Key", "Auto wind charge on key", Category.MISC); addSettings(delay, autoJump); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_G) == GLFW.GLFW_PRESS && timer.hasElapsedTime(delay.getValueInt(), true)) {
            int ws = -1; for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).getItem() == Items.WIND_CHARGE) { ws = i; break; }
            if (ws == -1 || mc.player.getItemCooldownManager().isCoolingDown(Items.WIND_CHARGE.getDefaultStack())) return;
            if (autoJump.getValue() && mc.player.isOnGround()) mc.player.jump();
            int prev = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = ws;
            ((MinecraftClientAccessor)mc).invokeDoItemUse(); mc.player.getInventory().selectedSlot = prev;
        }
    }
}