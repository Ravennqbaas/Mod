package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class InventoryCleaner extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 0, 200, 50, 10);
    private final BooleanSetting keepTools = new BooleanSetting("Keep Tools", true);
    private final TimerUtil timer = new TimerUtil();

    public InventoryCleaner() { super("Inventory Cleaner", "Drop trash items", Category.PLAYER); addSettings(delay, keepTools); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.currentScreen instanceof InventoryScreen) || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        for (int i = 9; i < 45; i++) {
            var s = mc.player.currentScreenHandler.getSlot(i).getStack();
            if (s.isEmpty() || (keepTools.getValue() && isTool(s)) || isValuable(s)) continue;
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i, 0, SlotActionType.THROW, mc.player);
            return;
        }
    }

    private boolean isTool(net.minecraft.item.ItemStack s) { String n = s.getItem().toString().toLowerCase(); return n.contains("sword") || n.contains("pickaxe") || n.contains("axe") || n.contains("shovel"); }
    private boolean isValuable(net.minecraft.item.ItemStack s) { var i = s.getItem(); return i == Items.DIAMOND || i == Items.NETHERITE_INGOT || i == Items.ENDER_PEARL || i == Items.TOTEM_OF_UNDYING || i == Items.GOLDEN_APPLE; }
}