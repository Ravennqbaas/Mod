package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.math.TimerUtil;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class HoverTotem extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 50, 500, 150, 25);
    private final TimerUtil timer = new TimerUtil();

    public HoverTotem() { super("Hover Totem", "Auto totem on hover", Category.MISC); addSettings(delay); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !(mc.currentScreen instanceof InventoryScreen) || !timer.hasElapsedTime(delay.getValueInt(), true)) return;
        var h = mc.player.currentScreenHandler;
        for (int i = 9; i < 36; i++) if (h.getSlot(i).getStack().getItem() == Items.TOTEM_OF_UNDYING) {
            if (mc.player.getOffHandStack().isEmpty() || mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) { mc.interactionManager.clickSlot(h.syncId, i, 40, SlotActionType.SWAP, mc.player); return; }
        }
    }
}