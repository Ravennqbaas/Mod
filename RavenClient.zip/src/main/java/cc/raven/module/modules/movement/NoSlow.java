package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import net.minecraft.util.math.Vec3d;

public final class NoSlow extends Module {
    private final BooleanSetting eating = new BooleanSetting("Eating", true);
    private final BooleanSetting blocking = new BooleanSetting("Blocking", true);

    public NoSlow() { super("NoSlow", "Prevents slowdown when using items", Category.MOVEMENT); addSettings(eating, blocking); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.player.isUsingItem()) return;
        if ((eating.getValue() && mc.player.getActiveItem().getItem().getFoodComponent() != null) ||
            (blocking.getValue() && mc.player.isBlocking())) {
            Vec3d vel = mc.player.getVelocity();
            mc.player.setVelocity(vel.x * 1.2, vel.y, vel.z * 1.2);
        }
    }
}