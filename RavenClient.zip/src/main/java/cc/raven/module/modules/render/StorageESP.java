package cc.raven.module.modules.render;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.ColorSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.render.RendererUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.*;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public final class StorageESP extends Module {
    private final BooleanSetting chests = new BooleanSetting("Chests", true);
    private final BooleanSetting shulkers = new BooleanSetting("Shulkers", true);
    private final BooleanSetting throughWalls = new BooleanSetting("Through Walls", true);
    private final NumberSetting range = new NumberSetting("Range", 8, 128, 64, 8);
    private final ColorSetting color = new ColorSetting("Color", new Color(255, 200, 50, 200));

    public StorageESP() { super("Storage ESP", "Highlights storage containers", Category.RENDER); addSettings(chests, shulkers, throughWalls, range, color); }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull()) return;
        List<BlockPos> storages = findStorages();
        if (storages.isEmpty()) return;

        RendererUtils.setupRender();
        if (throughWalls.getValue()) RenderSystem.disableDepthTest();
        var matrices = event.getMatrixStack();
        var camera = mc.gameRenderer.getCamera().getPos();
        var buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        var matrix = matrices.peek().getPositionMatrix();
        Color c = color.getValue();
        float r = c.getRed() / 255f, g = c.getGreen() / 255f, b = c.getBlue() / 255f, a = c.getAlpha() / 255f;

        for (BlockPos pos : storages) {
            double dx = pos.getX() - camera.x, dy = pos.getY() - camera.y, dz = pos.getZ() - camera.z;
            float x1 = (float)dx, y1 = (float)dy, z1 = (float)dz, x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;
            buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y1, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y1, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y1, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y2, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y2, z1).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a * 0.3f).next();
            buffer.vertex(matrix, x1, y2, z2).color(r, g, b, a * 0.3f).next();
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        if (throughWalls.getValue()) RenderSystem.enableDepthTest();
        RendererUtils.endRender();
    }

    private List<BlockPos> findStorages() {
        List<BlockPos> result = new ArrayList<>();
        int r = range.getValueInt();
        BlockPos center = mc.player.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = center.add(x, y, z);
            Block b = mc.world.getBlockState(pos).getBlock();
            if ((chests.getValue() && (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.ENDER_CHEST)) ||
                (shulkers.getValue() && b.toString().contains("shulker_box"))) result.add(pos);
        }
        return result;
    }
}