package cc.raven.module.modules.player;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.mixin.MinecraftClientAccessor;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.item.Items;

public final class AutoEat extends Module {
    private final NumberSetting hunger = new NumberSetting("Hunger", 1, 20, 17, 1);
    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", true);
    private int originalSlot = -1;
    private boolean eating;

    public AutoEat() { super("Auto Eat", "Auto eat when hungry", Category.PLAYER); addSettings(hunger, autoSwitch); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (eating) { if (!mc.player.isUsingItem()) { eating = false; if (originalSlot != -1) { mc.player.getInventory().selectedSlot = originalSlot; originalSlot = -1; } } return; }
        if (mc.player.getHungerManager().getFoodLevel() >= hunger.getValueInt()) return;

        int food = -1;
        for (int i = 0; i < 9; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem().getFoodComponent() != null && s.getItem() != Items.GOLDEN_APPLE && s.getItem() != Items.ENCHANTED_GOLDEN_APPLE) { food = i; break; }
        }
        if (food == -1) return;
        if (autoSwitch.getValue()) { originalSlot = mc.player.getInventory().selectedSlot; mc.player.getInventory().selectedSlot = food; }
        ((MinecraftClientAccessor) mc).invokeDoItemUse();
        eating = true;
    }
}