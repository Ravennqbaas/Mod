package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;

public final class Speed extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 0.1, 2.0, 0.5, 0.05);

    public Speed() { super("Speed", "Move faster", Category.MOVEMENT); addSettings(speed); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.player.isOnGround() || !isMoving()) return;
        Vec3d forward = Vec3d.fromPolar(0, mc.player.getYaw()).multiply(speed.getValue() * 0.2);
        mc.player.setVelocity(forward.x, mc.player.getVelocity().y, forward.z);
    }

    private boolean isMoving() { return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed(); }
}