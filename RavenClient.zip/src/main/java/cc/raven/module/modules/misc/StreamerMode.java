package cc.raven.module.modules.misc;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.BooleanSetting;

public final class StreamerMode extends Module {
    private final BooleanSetting hideGUI = new BooleanSetting("Hide GUI", true);
    private final BooleanSetting hideModuleNames = new BooleanSetting("Hide Names", true);

    public StreamerMode() { super("Streamer Mode", "Hides client from streams", Category.MISC); addSettings(hideGUI, hideModuleNames); }
    public boolean shouldHideGUI() { return isEnabled() && hideGUI.getValue(); }
    public boolean shouldHideNames() { return isEnabled() && hideModuleNames.getValue(); }
}