package cc.raven.module.modules.client;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;

public class Debugger extends Module {
    public Debugger() { super("Debugger", "Debugs packets for development", Category.CLIENT); }

    @EventTarget
    public void onPacketSend(PacketEvent e) {
        if (isNull() || !(e.getPacket() instanceof ClickSlotC2SPacket p)) return;
        ChatUtil.addChatMessage("ClickSlot: slot=" + p.getSlot() + " btn=" + p.getButton() + " action=" + p.getActionType());
    }
}