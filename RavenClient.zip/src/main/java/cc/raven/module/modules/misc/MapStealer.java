package cc.raven.module.modules.misc;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.network.PacketEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.utils.mc.ChatUtil;
import net.minecraft.network.packet.s2c.play.MapUpdateS2CPacket;

public final class MapStealer extends Module {
    private int stolen;

    public MapStealer() { super("Map Stealer", "Steals server maps", Category.MISC); }

    @EventTarget
    private void onPacket(PacketEvent event) {
        if (isNull() || !(event.getPacket() instanceof MapUpdateS2CPacket)) return;
        stolen++; if (stolen % 5 == 0) ChatUtil.addChatMessage("§aMaps: §f" + stolen);
    }
}