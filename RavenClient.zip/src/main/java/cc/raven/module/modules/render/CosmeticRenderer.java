package cc.raven.module.modules.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public final class CosmeticRenderer {
    private static boolean initialized = false;

    public static void init() { if (!initialized) { CosmeticManager.loadConfig(); initialized = true; } }

    public static void renderHat(MatrixStack matrices, VertexConsumerProvider vcp, int light, int overlay) {
        String hat = CosmeticManager.getActiveHat();
        if (hat.equals("none")) return;
        Identifier tex = CosmeticManager.getTexture("hat_" + hat);
        if (tex == null) return;
        matrices.push();
        matrices.translate(0, 1.8, 0);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));
        matrices.pop();
    }
}