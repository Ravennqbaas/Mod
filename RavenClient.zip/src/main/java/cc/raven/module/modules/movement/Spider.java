package cc.raven.module.modules.movement;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.player.TickEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;

public final class Spider extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 0.1, 2.0, 0.5, 0.1);

    public Spider() { super("Spider", "Climb walls", Category.MOVEMENT); addSettings(speed); }

    @EventTarget
    private void onTick(TickEvent event) {
        if (isNull() || !mc.player.horizontalCollision || !mc.options.forwardKey.isPressed()) return;
        mc.player.setVelocity(mc.player.getVelocity().x, speed.getValue() * 0.4, mc.player.getVelocity().z);
    }
}