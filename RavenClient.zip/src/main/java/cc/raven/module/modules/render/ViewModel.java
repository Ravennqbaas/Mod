package cc.raven.module.modules.render;

import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.setting.NumberSetting;

public final class ViewModel extends Module {
    private final NumberSetting posX = new NumberSetting("Pos X", -2.0, 2.0, 0.0, 0.05);
    private final NumberSetting posY = new NumberSetting("Pos Y", -2.0, 2.0, 0.0, 0.05);
    private final NumberSetting posZ = new NumberSetting("Pos Z", -2.0, 2.0, 0.0, 0.05);
    private final NumberSetting scale = new NumberSetting("Scale", 0.1, 3.0, 1.0, 0.05);

    public ViewModel() { super("View Model", "Change held item position/scale", Category.RENDER); addSettings(posX, posY, posZ, scale); }

    public float getPosX() { return posX.getValueFloat(); }
    public float getPosY() { return posY.getValueFloat(); }
    public float getPosZ() { return posZ.getValueFloat(); }
    public float getScale() { return scale.getValueFloat(); }
}