package cc.raven.module.modules.combat;

import cc.raven.event.EventTarget;
import cc.raven.event.impl.render.Render3DEvent;
import cc.raven.module.Category;
import cc.raven.module.Module;
import cc.raven.module.modules.misc.Teams;
import cc.raven.module.setting.BooleanSetting;
import cc.raven.module.setting.NumberSetting;
import cc.raven.utils.friend.FriendManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
    private final NumberSetting maxYaw = new NumberSetting("Max Yaw Speed", 0.1, 5.0, 2.0, 0.1);
    private final NumberSetting minYaw = new NumberSetting("Min Yaw Speed", 0.1, 5.0, 2.0, 0.1);
    private final NumberSetting fov = new NumberSetting("FOV", 10.0, 180.0, 90.0, 1.0);
    private final NumberSetting range = new NumberSetting("Range", 1.0, 10.0, 4.5, 0.1);
    private final NumberSetting smoothing = new NumberSetting("Smoothing", 1.0, 20.0, 10.0, 0.5);
    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);
    private final BooleanSetting weaponsOnly = new BooleanSetting("Weapons Only", false);
    private final BooleanSetting throughWalls = new BooleanSetting("Through Walls", false);
    private long lastUpdate = 0;
    private float baseSpeed = 10f;
    private float nextSpeed = 10f;
    private long lastSpeedChange = 0;

    public AimAssist() {
        super("Aim Assist", "Helps you aim at targets", Category.COMBAT);
        addSettings(maxYaw, minYaw, fov, range, smoothing, targetPlayers, weaponsOnly, throughWalls);
    }

    @EventTarget
    private void onRender3D(Render3DEvent event) {
        if (isNull() || mc.currentScreen != null) return;
        if (weaponsOnly.getValue() && !isHoldingWeapon()) return;

        Entity target = findTarget();
        if (target == null) return;
        if (!throughWalls.getValue() && !mc.player.canSee(target)) return;

        Vec3d targetPos = new Vec3d(target.getX(), target.getEyeY(), target.getZ());
        Vec3d diff = targetPos.subtract(mc.player.getEyePos());
        float ty = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
        float tp = (float) -Math.toDegrees(Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));

        float yDiff = MathHelper.wrapDegrees(ty - mc.player.getYaw());
        float pDiff = tp - mc.player.getPitch();
        if (Math.hypot(yDiff, pDiff) < 0.3f) return;

        long now = System.currentTimeMillis();
        if (lastUpdate == 0) { lastUpdate = now; return; }
        float delta = (now - lastUpdate) / 1000f;
        lastUpdate = now;
        if (delta < 0.001f || delta > 0.1f) return;

        if (now - lastSpeedChange > 200) {
            nextSpeed = MathHelper.clamp(nextSpeed + (float)(Math.random() - 0.5) * 10f, 8f, 100f);
            lastSpeedChange = now;
        }
        baseSpeed = baseSpeed * 0.9f + nextSpeed * 0.1f;

        float eased = 1f - (float)Math.pow(1f - Math.min((float)Math.hypot(yDiff, pDiff) / 10f, 1f), 3);
        float factor = eased * (smoothing.getValueFloat() / 10f) * delta;

        mc.player.setYaw(mc.player.getYaw() + yDiff * factor);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pDiff * factor, -89f, 89f));
    }

    private Entity findTarget() {
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || e == mc.player) continue;
            if (Teams.isTeammate(e)) continue;
            if (e instanceof PlayerEntity p && FriendManager.isFriend(p.getUuid())) continue;
            if (!targetPlayers.getValue() && e instanceof PlayerEntity) continue;
            double dist = mc.player.distanceTo(e);
            if (dist > range.getValue()) continue;
            Vec3d tp = new Vec3d(e.getX(), e.getEyeY(), e.getZ());
            Vec3d diff = tp.subtract(mc.player.getEyePos());
            float ty = (float)Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            float tp2 = (float)-Math.toDegrees(Math.atan2(diff.y, Math.sqrt(diff.x*diff.x+diff.z*diff.z)));
            double fovDist = Math.hypot(MathHelper.wrapDegrees(ty - mc.player.getYaw()), tp2 - mc.player.getPitch());
            if (fovDist <= fov.getValue() / 2.0) {
                double score = dist + fovDist * 2.0;
                if (score < bestScore) { bestScore = score; best = e; }
            }
        }
        return best;
    }

    private boolean isHoldingWeapon() {
        var item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem;
    }
}