package cc.raven.module;

import cc.raven.RavenClient;
import cc.raven.module.setting.Setting;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private int key;
    private final Category category;
    private boolean enabled;
    private final List<Setting> settings = new ArrayList<>();

    public Module(String name, String description, int key, Category category) {
        this.name = name; this.description = description; this.key = key; this.category = category; this.enabled = false;
    }

    public Module(String name, String description, Category category) {
        this(name, description, -1, category);
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            if (enabled) onEnable(); else onDisable();
        }
    }

    public void toggle() { setEnabled(!enabled); }

    public void onEnable() { RavenClient.INSTANCE.getEventBus().register(this); }
    public void onDisable() { RavenClient.INSTANCE.getEventBus().unregister(this); }

    public void addSetting(Setting setting) { settings.add(setting); }
    public void addSettings(Setting... settings) { for (Setting s : settings) addSetting(s); }
    public List<Setting> getSettings() { return settings; }
    public boolean isNull() { return mc.player == null || mc.world == null; }
}