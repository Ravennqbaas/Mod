package cc.raven.module.setting;

import org.lwjgl.glfw.GLFW;

public class KeybindSetting extends Setting {
    private int keyCode;
    private final boolean holdMode;

    public KeybindSetting(String name, int defaultKey, boolean holdMode) {
        super(name);
        this.keyCode = defaultKey;
        this.holdMode = holdMode;
    }

    public int getKeyCode() { return keyCode; }
    public void setKeyCode(int keyCode) { this.keyCode = keyCode; triggerChange(); }
    public boolean isHoldMode() { return holdMode; }
    public String getKeyName() {
        if (keyCode == -1) return "None";
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        return name != null ? name.toUpperCase() : "KEY" + keyCode;
    }
}