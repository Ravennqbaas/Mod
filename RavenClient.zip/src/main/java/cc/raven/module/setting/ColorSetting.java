package cc.raven.module.setting;

import java.awt.Color;

public class ColorSetting extends Setting {
    private Color value;

    public ColorSetting(String name, Color defaultValue) {
        super(name);
        this.value = defaultValue;
    }

    public Color getValue() { return value; }
    public int getRGB() { return value.getRGB(); }
    public void setValue(Color value) { this.value = value; triggerChange(); }
    public void setValue(int red, int green, int blue, int alpha) {
        setValue(new Color(
            Math.min(255, Math.max(0, red)),
            Math.min(255, Math.max(0, green)),
            Math.min(255, Math.max(0, blue)),
            Math.min(255, Math.max(0, alpha))
        ));
    }
    public int getRed() { return value.getRed(); }
    public int getGreen() { return value.getGreen(); }
    public int getBlue() { return value.getBlue(); }
    public int getAlpha() { return value.getAlpha(); }
}