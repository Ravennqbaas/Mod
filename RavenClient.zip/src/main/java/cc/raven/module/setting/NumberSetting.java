package cc.raven.module.setting;

import net.minecraft.util.math.MathHelper;

public class NumberSetting extends Setting {
    private double value;
    private final double min, max, increment;

    public NumberSetting(String name, double min, double max, double defaultValue, double increment) {
        super(name);
        this.min = min; this.max = max; this.value = defaultValue; this.increment = increment;
    }

    public double getValue() { return value; }
    public float getValueFloat() { return (float) value; }
    public int getValueInt() { return (int) Math.round(value); }
    public void setValue(double value) { this.value = MathHelper.clamp(value, min, max); triggerChange(); }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return increment; }
}