package cc.raven.module.setting;

import net.minecraft.util.math.MathHelper;

public class RangeSetting extends Setting {
    private double minValue, maxValue;
    private final double absoluteMin, absoluteMax, increment;

    public RangeSetting(String name, double absMin, double absMax, double defaultMin, double defaultMax, double increment) {
        super(name);
        this.absoluteMin = absMin; this.absoluteMax = absMax;
        this.minValue = defaultMin; this.maxValue = defaultMax;
        this.increment = increment;
    }

    public double getMinValue() { return minValue; }
    public double getMaxValue() { return maxValue; }
    public float getMinValueFloat() { return (float) minValue; }
    public float getMaxValueFloat() { return (float) maxValue; }
    public int getMinValueInt() { return (int) Math.round(minValue); }
    public int getMaxValueInt() { return (int) Math.round(maxValue); }
    public void setMinValue(double minValue) { this.minValue = MathHelper.clamp(minValue, absoluteMin, maxValue - increment); triggerChange(); }
    public void setMaxValue(double maxValue) { this.maxValue = MathHelper.clamp(maxValue, minValue + increment, absoluteMax); triggerChange(); }
    public double getIncrement() { return increment; }
}