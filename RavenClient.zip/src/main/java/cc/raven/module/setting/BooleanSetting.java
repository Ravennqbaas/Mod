package cc.raven.module.setting;

public class BooleanSetting extends Setting {
    private boolean value;

    public BooleanSetting(String name, boolean defaultValue) {
        super(name);
        this.value = defaultValue;
    }

    public boolean getValue() { return value; }
    public void setValue(boolean value) { this.value = value; triggerChange(); }
    public void toggle() { setValue(!value); }
}