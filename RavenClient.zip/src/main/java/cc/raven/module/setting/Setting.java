package cc.raven.module.setting;

import java.util.function.Consumer;

public class Setting {
    private final String name;
    private Consumer<Setting> onChange;

    public Setting(String name) { this.name = name; }
    public String getName() { return name; }
    public void setOnChange(Consumer<Setting> onChange) { this.onChange = onChange; }
    public void triggerChange() { if (onChange != null) onChange.accept(this); }
}