package cc.raven.module.setting;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
    private String mode;
    private final List<String> modes;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name);
        this.modes = Arrays.asList(modes);
        this.mode = defaultMode;
    }

    public String getMode() { return mode; }
    public void setMode(String mode) { if (modes.contains(mode)) { this.mode = mode; triggerChange(); } }
    public List<String> getModes() { return modes; }
    public boolean isMode(String mode) { return this.mode.equals(mode); }
    public void cycle() {
        int index = modes.indexOf(mode);
        index = (index + 1) % modes.size();
        setMode(modes.get(index));
    }
}