package cc.raven.module;

import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module module) { modules.add(module); }

    public List<Module> getModules() { return modules; }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream().filter(m -> m.getCategory() == category)
                .sorted(Comparator.comparing(Module::getName)).collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> Optional<T> getModule(Class<T> clazz) {
        return modules.stream().filter(m -> m.getClass() == clazz).map(m -> (T) m).findFirst();
    }

    public Optional<Module> getModuleByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }
}