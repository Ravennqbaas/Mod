package cc.raven.module;

public enum Category {
    COMBAT("Combat", "⚔"),
    MOVEMENT("Movement", "🏃"),
    PLAYER("Player", "👤"),
    RENDER("Render", "👁"),
    MISC("Misc", "📦"),
    CLIENT("Client", "⚙");

    public final String name;
    public final String icon;

    Category(String name, String icon) {
        this.name = name;
        this.icon = icon;
    }
}