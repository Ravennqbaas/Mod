package cc.raven.mixin;

import cc.raven.RavenClient;
import cc.raven.event.impl.player.AttackEvent;
import cc.raven.event.impl.player.DoAttackEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void onDoAttack(CallbackInfo ci) {
        DoAttackEvent event = new DoAttackEvent();
        RavenClient.INSTANCE.getEventBus().post(event);
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onHandleInputEvents(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient) (Object) this;
        if (mc.player != null && mc.options.attackKey.wasPressed() && mc.crosshairTarget != null) {
            Entity target = mc.crosshairTarget.getEntity();
            if (target != null) {
                RavenClient.INSTANCE.getEventBus().post(new AttackEvent(target));
            }
        }
    }
}