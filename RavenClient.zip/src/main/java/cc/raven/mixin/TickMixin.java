package cc.raven.mixin;

import cc.raven.RavenClient;
import cc.raven.event.impl.player.TickEvent;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class TickMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTickPre(CallbackInfo ci) {
        RavenClient.INSTANCE.getEventBus().post(new TickEvent(TickEvent.Phase.PRE));
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void onTickPost(CallbackInfo ci) {
        RavenClient.INSTANCE.getEventBus().post(new TickEvent(TickEvent.Phase.POST));
    }
}