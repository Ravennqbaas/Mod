package cc.raven.mixin;

import cc.raven.RavenClient;
import cc.raven.event.impl.player.ItemUseEvent;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class ItemUseMixin {

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void onDoItemUse(CallbackInfo ci) {
        ItemUseEvent event = new ItemUseEvent();
        RavenClient.INSTANCE.getEventBus().post(event);
        if (event.isCancelled()) ci.cancel();
    }
}