package cc.raven.config;

import cc.raven.RavenClient;
import java.util.*;

public class ConfigManager {

    private Config currentConfig;
    private static final String DEFAULT_CONFIG = "default";

    public ConfigManager() {
        currentConfig = Config.create(DEFAULT_CONFIG);
    }

    public void loadDefault() {
        if (Config.exists(DEFAULT_CONFIG)) loadConfig(DEFAULT_CONFIG);
        else saveCurrentConfig();
    }

    public void saveCurrentConfig() {
        if (currentConfig != null) currentConfig.save();
    }

    public void loadConfig(String name) {
        Config config = Config.create(name);
        if (Config.exists(name)) {
            config.load();
            currentConfig = config;
            RavenClient.LOGGER.info("Config loaded: {}", name);
        }
    }

    public void saveConfig(String name) {
        Config.create(name).save();
    }

    public void deleteConfig(String name) {
        Config.create(name).delete();
    }

    public List<String> getConfigNames() {
        List<String> names = new ArrayList<>();
        for (Config config : Config.getAvailableConfigs()) names.add(config.getName());
        return names;
    }

    public String getCurrentConfigName() {
        return currentConfig != null ? currentConfig.getName() : "None";
    }

    public Config getCurrentConfig() { return currentConfig; }
}