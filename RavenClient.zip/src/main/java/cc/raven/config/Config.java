package cc.raven.config;

import cc.raven.RavenClient;
import cc.raven.module.Module;
import cc.raven.module.setting.*;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Config {

    private final String name;
    private final Path configFile;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("RavenClient/configs");

    public Config(String name) {
        this.name = name;
        this.configFile = CONFIG_DIR.resolve(name + ".json");
    }

    public String getName() { return name; }

    public void save() {
        try {
            Files.createDirectories(CONFIG_DIR);
            JsonObject root = new JsonObject();
            root.addProperty("name", name);
            root.addProperty("version", RavenClient.VERSION);

            JsonArray modulesArray = new JsonArray();
            for (Module module : RavenClient.INSTANCE.getModuleManager().getModules()) {
                JsonObject moduleObj = new JsonObject();
                moduleObj.addProperty("name", module.getName());
                moduleObj.addProperty("enabled", module.isEnabled());
                moduleObj.addProperty("key", module.getKey());

                JsonArray settingsArray = new JsonArray();
                for (Setting setting : module.getSettings()) {
                    JsonObject settingObj = new JsonObject();
                    settingObj.addProperty("name", setting.getName());

                    if (setting instanceof BooleanSetting bs) {
                        settingObj.addProperty("type", "boolean");
                        settingObj.addProperty("value", bs.getValue());
                    } else if (setting instanceof NumberSetting ns) {
                        settingObj.addProperty("type", "number");
                        settingObj.addProperty("value", ns.getValue());
                    } else if (setting instanceof ModeSetting ms) {
                        settingObj.addProperty("type", "mode");
                        settingObj.addProperty("value", ms.getMode());
                    } else if (setting instanceof ColorSetting cs) {
                        settingObj.addProperty("type", "color");
                        settingObj.addProperty("red", cs.getRed());
                        settingObj.addProperty("green", cs.getGreen());
                        settingObj.addProperty("blue", cs.getBlue());
                        settingObj.addProperty("alpha", cs.getAlpha());
                    } else if (setting instanceof KeybindSetting ks) {
                        settingObj.addProperty("type", "keybind");
                        settingObj.addProperty("value", ks.getKeyCode());
                    } else if (setting instanceof RangeSetting rs) {
                        settingObj.addProperty("type", "range");
                        settingObj.addProperty("min", rs.getMinValue());
                        settingObj.addProperty("max", rs.getMaxValue());
                    }
                    settingsArray.add(settingObj);
                }
                moduleObj.add("settings", settingsArray);
                modulesArray.add(moduleObj);
            }
            root.add("modules", modulesArray);

            Writer writer = Files.newBufferedWriter(configFile, StandardCharsets.UTF_8);
            GSON.toJson(root, writer);
            writer.close();
        } catch (Exception e) {
            RavenClient.LOGGER.error("Config save error: {}", e.getMessage());
        }
    }

    public void load() {
        if (!Files.exists(configFile)) return;
        try {
            Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            reader.close();
            if (!root.has("modules")) return;

            JsonArray modulesArray = root.getAsJsonArray("modules");
            for (JsonElement moduleElement : modulesArray) {
                JsonObject moduleObj = moduleElement.getAsJsonObject();
                String moduleName = moduleObj.get("name").getAsString();

                RavenClient.INSTANCE.getModuleManager().getModuleByName(moduleName).ifPresent(module -> {
                    if (moduleObj.has("enabled")) {
                        boolean wasEnabled = moduleObj.get("enabled").getAsBoolean();
                        if (wasEnabled != module.isEnabled()) module.setEnabled(wasEnabled);
                    }
                    if (moduleObj.has("key")) module.setKey(moduleObj.get("key").getAsInt());
                    if (moduleObj.has("settings")) {
                        JsonArray settingsArray = moduleObj.getAsJsonArray("settings");
                        for (JsonElement settingElement : settingsArray) {
                            JsonObject settingObj = settingElement.getAsJsonObject();
                            String settingName = settingObj.get("name").getAsString();
                            String type = settingObj.get("type").getAsString();

                            for (Setting setting : module.getSettings()) {
                                if (!setting.getName().equals(settingName)) continue;
                                switch (type) {
                                    case "boolean" -> ((BooleanSetting) setting).setValue(settingObj.get("value").getAsBoolean());
                                    case "number" -> ((NumberSetting) setting).setValue(settingObj.get("value").getAsDouble());
                                    case "mode" -> ((ModeSetting) setting).setMode(settingObj.get("value").getAsString());
                                    case "color" -> ((ColorSetting) setting).setValue(
                                        settingObj.get("red").getAsInt(), settingObj.get("green").getAsInt(),
                                        settingObj.get("blue").getAsInt(), settingObj.get("alpha").getAsInt());
                                    case "keybind" -> ((KeybindSetting) setting).setKeyCode(settingObj.get("value").getAsInt());
                                    case "range" -> {
                                        RangeSetting rs = (RangeSetting) setting;
                                        rs.setMinValue(settingObj.get("min").getAsDouble());
                                        rs.setMaxValue(settingObj.get("max").getAsDouble());
                                    }
                                }
                            }
                        }
                    }
                });
            }
        } catch (Exception e) {
            RavenClient.LOGGER.error("Config load error: {}", e.getMessage());
        }
    }

    public boolean delete() {
        try { return Files.deleteIfExists(configFile); } catch (Exception e) { return false; }
    }

    public static List<Config> getAvailableConfigs() {
        List<Config> configs = new ArrayList<>();
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.list(CONFIG_DIR).filter(p -> p.toString().endsWith(".json"))
                .forEach(p -> configs.add(new Config(p.getFileName().toString().replace(".json", ""))));
        } catch (Exception ignored) {}
        return configs;
    }

    public static Config create(String name) { return new Config(name); }
    public static boolean exists(String name) { return Files.exists(CONFIG_DIR.resolve(name + ".json")); }
}