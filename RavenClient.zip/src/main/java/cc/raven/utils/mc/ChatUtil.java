package cc.raven.utils.mc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class ChatUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final String PREFIX = "§8[§4Raven§8] §f";

    public static void addChatMessage(String message) {
        if (mc.player == null) return;
        mc.player.sendMessage(Text.literal(PREFIX + message), false);
    }

    public static void addRawMessage(String message) {
        if (mc.player == null) return;
        mc.player.sendMessage(Text.literal(message), false);
    }
}