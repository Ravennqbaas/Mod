package cc.raven.utils.mc;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.World;

public final class EnchantmentUtil {
    public static boolean hasEnchantment(ItemStack stack, World world, RegistryKey<Enchantment> key) {
        if (stack.isEmpty() || world == null) return false;
        var enchantment = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT).get(key);
        if (enchantment == null) return false;
        return stack.getEnchantments().getEnchantments().stream()
                .anyMatch(e -> e.getKey().getRegistryEntry().getKey().get().equals(key));
    }
}