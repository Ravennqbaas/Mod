package cc.raven.utils.mc;

import net.minecraft.item.ItemStack;

public final class ItemUtil {
    public static boolean isFood(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem().getFoodComponent() != null;
    }

    public static boolean isTool(ItemStack stack) {
        if (stack.isEmpty()) return false;
        String name = stack.getItem().toString().toLowerCase();
        return name.contains("pickaxe") || name.contains("axe") || 
               name.contains("shovel") || name.contains("hoe");
    }
}