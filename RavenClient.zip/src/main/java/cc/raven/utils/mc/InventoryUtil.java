package cc.raven.utils.mc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class InventoryUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static int findItemInHotbar(Item item) {
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return i;
        }
        return -1;
    }

    public static boolean hasItem(Item item) {
        if (mc.player == null) return false;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return true;
        }
        return false;
    }

    public static boolean hasItemInHotbar(Item item) {
        return findItemInHotbar(item) != -1;
    }

    public static void swapToSlot(Item item) {
        int slot = findItemInHotbar(item);
        if (slot != -1 && mc.player != null) mc.player.getInventory().selectedSlot = slot;
    }

    public static void swapToWeapon(Class<? extends Item> weaponClass) {
        if (mc.player == null) return;
        for (int i = 0; i < 9; i++) {
            if (weaponClass.isInstance(mc.player.getInventory().getStack(i).getItem())) {
                mc.player.getInventory().selectedSlot = i;
                return;
            }
        }
    }

    public static boolean hasWeapon(Class<? extends Item> weaponClass) {
        if (mc.player == null) return false;
        for (int i = 0; i < 9; i++) {
            if (weaponClass.isInstance(mc.player.getInventory().getStack(i).getItem())) return true;
        }
        return false;
    }
}