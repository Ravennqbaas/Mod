package cc.raven.utils.friend;

import java.util.*;

public class FriendManager {
    private static final Set<UUID> friends = new HashSet<>();
    private static final Map<UUID, String> friendNames = new HashMap<>();

    public static boolean isFriend(UUID uuid) { return friends.contains(uuid); }
    public static void addFriend(UUID uuid, String name) { friends.add(uuid); friendNames.put(uuid, name); }
    public static void removeFriend(UUID uuid) { friends.remove(uuid); friendNames.remove(uuid); }
    public static String getName(UUID uuid) { return friendNames.getOrDefault(uuid, "Unknown"); }
    public static Set<UUID> getFriends() { return Collections.unmodifiableSet(friends); }
}