package cc.raven.utils.math;

import java.util.concurrent.ThreadLocalRandom;

public final class MathUtils {
    public static double randomDoubleBetween(double min, double max) {
        return min + ThreadLocalRandom.current().nextDouble() * (max - min);
    }

    public static int randomIntBetween(int min, int max) {
        return min + ThreadLocalRandom.current().nextInt(max - min + 1);
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}