package cc.raven.utils.math;

public final class TimerUtil {
    private long lastMS = System.currentTimeMillis();
    private long nanoTime = System.nanoTime();

    public void reset() {
        lastMS = System.currentTimeMillis();
        nanoTime = System.nanoTime();
    }

    public boolean hasElapsedTime(long milliseconds) {
        return System.currentTimeMillis() - lastMS >= milliseconds;
    }

    public boolean hasElapsedTime(long milliseconds, boolean reset) {
        if (hasElapsedTime(milliseconds)) {
            if (reset) this.reset();
            return true;
        }
        return false;
    }

    public long getElapsedTime() {
        return System.currentTimeMillis() - lastMS;
    }

    public void setElapsedTime(long time) {
        lastMS = System.currentTimeMillis() - time;
    }
}