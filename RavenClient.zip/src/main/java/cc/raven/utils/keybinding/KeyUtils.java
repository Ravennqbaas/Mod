package cc.raven.utils.keybinding;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class KeyUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isKeyPressed(int keyCode) {
        if (keyCode < 0 || mc.getWindow() == null) return false;
        return GLFW.glfwGetKey(mc.getWindow().getHandle(), keyCode) == GLFW.GLFW_PRESS;
    }
}