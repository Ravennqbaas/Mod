package cc.raven.utils.render;

import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.MinecraftClient;

public final class CompatShaders {
    private static ShaderProgram positionColor;

    public static ShaderProgram getPositionColor() {
        if (positionColor == null) {
            try {
                positionColor = new ShaderProgram(
                    MinecraftClient.getInstance().getResourceManager(),
                    "position_color", VertexFormats.POSITION_COLOR);
            } catch (Exception ignored) {}
        }
        return positionColor;
    }
}