package cc.raven.utils.render;

import com.mojang.blaze3d.systems.RenderSystem;

public final class RendererUtils {
    public static void setupRender() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
    }

    public static void endRender() {
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}