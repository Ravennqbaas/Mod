package cc.raven;

import cc.raven.config.ConfigManager;
import cc.raven.event.EventBus;
import cc.raven.gui.RavenClickGUI;
import cc.raven.module.Category;
import cc.raven.module.ModuleManager;
import cc.raven.module.modules.client.*;
import cc.raven.module.modules.combat.*;
import cc.raven.module.modules.misc.*;
import cc.raven.module.modules.movement.*;
import cc.raven.module.modules.player.*;
import cc.raven.module.modules.render.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RavenClient implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("RavenClient");
    public static final String NAME = "Raven Client";
    public static final String VERSION = "1.0.0";
    public static RavenClient INSTANCE;

    private final EventBus eventBus = new EventBus();
    private final ModuleManager moduleManager = new ModuleManager();
    private final ConfigManager configManager = new ConfigManager();

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        LOGGER.info("{} v{} starting...", NAME, VERSION);

        registerModules();
        registerEvents();
        configManager.loadDefault();
        CosmeticRenderer.init();

        LOGGER.info("{} loaded! {} modules ready.", NAME, moduleManager.getModules().size());
    }

    private void registerModules() {
        // Combat
        moduleManager.register(new AimAssist());
        moduleManager.register(new Anchor());
        moduleManager.register(new AutoClicker());
        moduleManager.register(new AutoCrystal());
        moduleManager.register(new AutoMace());
        moduleManager.register(new AutoPot());
        moduleManager.register(new BreachSwap());
        moduleManager.register(new ElytraHotSwap());
        moduleManager.register(new HitCob());
        moduleManager.register(new KeyCrystal());
        moduleManager.register(new KeyLava());
        moduleManager.register(new ShieldBreaker());
        moduleManager.register(new STap());
        moduleManager.register(new StunCob());
        moduleManager.register(new SwordHotSwap());
        moduleManager.register(new ThrowPot());
        moduleManager.register(new TotemHit());
        moduleManager.register(new TriggerBot());
        moduleManager.register(new Velocity());
        moduleManager.register(new WTap());

        // Movement
        moduleManager.register(new AutoFirework());
        moduleManager.register(new ElytraFly());
        moduleManager.register(new Jesus());
        moduleManager.register(new NoSlow());
        moduleManager.register(new RavenFlight());
        moduleManager.register(new Scaffold());
        moduleManager.register(new Speed());
        moduleManager.register(new Spider());
        moduleManager.register(new Sprint());
        moduleManager.register(new Step());

        // Player
        moduleManager.register(new AutoCrafter());
        moduleManager.register(new AutoDoubleHand());
        moduleManager.register(new AutoDrain());
        moduleManager.register(new AutoEat());
        moduleManager.register(new AutoExtinguish());
        moduleManager.register(new AutoMLG());
        moduleManager.register(new AutoRefill());
        moduleManager.register(new AutoTool());
        moduleManager.register(new AutoWeb());
        moduleManager.register(new ChestStealer());
        moduleManager.register(new CoverUp());
        moduleManager.register(new FastEXP());
        moduleManager.register(new FastMine());
        moduleManager.register(new InventoryCleaner());
        moduleManager.register(new NoEntityTrace());
        moduleManager.register(new NoFall());
        moduleManager.register(new PingSpoof());

        // Render
        moduleManager.register(new BlockESP());
        moduleManager.register(new CosmeticManager());
        moduleManager.register(new Fullbright());
        moduleManager.register(new NetheriteFinder());
        moduleManager.register(new NoRender());
        moduleManager.register(new RavenESP());
        moduleManager.register(new StorageESP());
        moduleManager.register(new Tracers());
        moduleManager.register(new ViewModel());

        // Misc
        moduleManager.register(new AACBypass());
        moduleManager.register(new AccountSwitcher());
        moduleManager.register(new AntiBot());
        moduleManager.register(new AntiCheatDetector());
        moduleManager.register(new ConfigManagerModule());
        moduleManager.register(new FakePlayer());
        moduleManager.register(new Freecam());
        moduleManager.register(new Friends());
        moduleManager.register(new HoverTotem());
        moduleManager.register(new Macro());
        moduleManager.register(new MapStealer());
        moduleManager.register(new PanicButton());
        moduleManager.register(new PearlCatch());
        moduleManager.register(new PearlKey());
        moduleManager.register(new Spammer());
        moduleManager.register(new StashFinder());
        moduleManager.register(new StreamerMode());
        moduleManager.register(new Teams());
        moduleManager.register(new TextureStealer());
        moduleManager.register(new WindChargeKey());

        // Client
        moduleManager.register(new ClickGUIModule());
        moduleManager.register(new ClientSettingsModule());
        moduleManager.register(new Debugger());
        moduleManager.register(new KeybindsModule());
    }

    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            var guiModule = moduleManager.getModule(ClickGUIModule.class);
            if (guiModule.isPresent()) {
                int guiKey = ((ClickGUIModule) guiModule.get()).getKey();
                if (guiKey != -1 && GLFW.glfwGetKey(client.getWindow().getHandle(), guiKey) == GLFW.GLFW_PRESS) {
                    client.setScreen(new RavenClickGUI());
                }
            }
        });
    }

    public EventBus getEventBus() { return eventBus; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public ConfigManager getConfigManager() { return configManager; }
}