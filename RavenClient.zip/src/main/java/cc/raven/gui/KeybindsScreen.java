package cc.raven.gui;

import cc.raven.RavenClient;
import cc.raven.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

public class KeybindsScreen extends Screen {
    private int selected = -1;
    private boolean listening = false;

    public KeybindsScreen() { super(Text.literal("Raven - Keybinds")); }

    @Override
    protected void init() {
        List<Module> mods = RavenClient.INSTANCE.getModuleManager().getModules();
        int y = 30;
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            String kn = m.getKey() == -1 ? "None" : GLFW.glfwGetKeyName(m.getKey(), 0);
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(m.getName() + " [" + kn + "]"), btn -> {
                selected = idx; listening = true;
            }).dimensions(10, y, 180, 18).build());
            y += 22;
        }
    }

    @Override
    public boolean keyPressed(int k, int s, int m) {
        if (listening && selected >= 0) {
            List<Module> mods = RavenClient.INSTANCE.getModuleManager().getModules();
            if (selected < mods.size()) mods.get(selected).setKey(k == GLFW.GLFW_KEY_ESCAPE ? -1 : k);
            listening = false; selected = -1; clearAndInit(); return true;
        }
        return super.keyPressed(k, s, m);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float d) {
        renderBackground(ctx, mx, my, d);
        ctx.drawCenteredTextWithShadow(textRenderer, "Raven Keybinds", width / 2, 8, 0xFF4444);
        if (listening) ctx.drawCenteredTextWithShadow(textRenderer, "Press a key... (ESC to clear)", width / 2, height - 20, 0xFFFF55);
        super.render(ctx, mx, my, d);
    }
}