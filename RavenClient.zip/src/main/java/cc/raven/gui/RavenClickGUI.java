package cc.raven.gui;

import cc.raven.RavenClient;
import cc.raven.gui.component.CategoryPanel;
import cc.raven.module.Category;
import cc.raven.module.modules.client.ClientSettingsModule;
import cc.raven.module.modules.misc.StreamerMode;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class RavenClickGUI extends Screen {

    private final List<CategoryPanel> categoryPanels = new ArrayList<>();
    private int mouseX, mouseY;
    private float guiScale = 1.0f;
    private long openTime;
    private long lastFrame;
    private float smoothFactor = 0.0f;

    public RavenClickGUI() {
        super(Text.literal("Raven Client"));
        this.openTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        super.init();
        categoryPanels.clear();
        guiScale = ClientSettingsModule.getGuiScale();
        int startX = (int)(30 / guiScale);
        int startY = (int)(30 / guiScale);
        int panelWidth = (int)(105 / guiScale);
        int gap = (int)(8 / guiScale);
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            categoryPanels.add(new CategoryPanel(categories[i],
                startX + (panelWidth + gap) * i, startY, panelWidth, (int)(300 / guiScale)));
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        var sm = RavenClient.INSTANCE.getModuleManager().getModule(StreamerMode.class);
        if (sm.isPresent() && ((StreamerMode)sm.get()).isEnabled() && ((StreamerMode)sm.get()).shouldHideGUI()) return;

        this.mouseX = mouseX; this.mouseY = mouseY;
        guiScale = ClientSettingsModule.getGuiScale();
        long now = System.currentTimeMillis();
        if (lastFrame == 0) lastFrame = now;
        long frameDelta = now - lastFrame; lastFrame = now;
        float targetSmooth = Math.min(1.0f, (now - openTime) / 300.0f);
        smoothFactor += (targetSmooth - smoothFactor) * Math.min(1.0f, frameDelta / 16.0f);

        renderBackground(context);
        drawLogo(context);
        context.getMatrices().push();
        context.getMatrices().scale(guiScale, guiScale, 1.0f);
        for (CategoryPanel panel : categoryPanels) {
            panel.render(context, (int)(mouseX / guiScale), (int)(mouseY / guiScale), delta, smoothFactor);
        }
        context.getMatrices().pop();
        drawTooltip(context);
    }

    private void renderBackground(DrawContext context) {
        for (int y = 0; y < height; y += 4) {
            float ratio = (float) y / height;
            int r = (int)(10 + ratio * 10), g = (int)(8 + ratio * 7), b = (int)(20 + ratio * 15);
            context.fill(0, y, width, y + 4, new Color(r, g, b, 200 + (int)(ratio * 55)).getRGB());
        }
        if (ClientSettingsModule.isSnowEffectEnabled()) {
            for (int i = 0; i < 15; i++) {
                float fx = (float)((mouseX * 0.3 + width * 0.4 + Math.sin(openTime * 0.001 + i * 1.7) * 200) % width);
                float fy = (float)((openTime * 0.02 + i * 40) % height);
                int alpha = 10 + (int)(Math.sin(openTime * 0.003 + i) * 8);
                context.fill((int)fx - 3, (int)fy - 8, (int)fx + 3, (int)fy + 8, new Color(60, 50, 80, alpha).getRGB());
            }
        }
    }

    private void drawLogo(DrawContext context) {
        context.fill(15, 8, 43, 22, new Color(180, 40, 40, 200).getRGB());
        context.fill(17, 10, 41, 20, new Color(20, 10, 25, 220).getRGB());
        context.drawText(textRenderer, "◈", 21, 10, new Color(200, 50, 50).getRGB(), true);
        context.drawText(textRenderer, "RAVEN", 47, 9, new Color(200, 50, 50, 220).getRGB(), true);
        context.drawText(textRenderer, "CLIENT", 47, 18, new Color(140, 100, 120, 180).getRGB(), true);
    }

    private void drawTooltip(DrawContext context) {
        for (CategoryPanel panel : categoryPanels) {
            String tip = panel.getHoveredModuleDescription((int)(mouseX / guiScale), (int)(mouseY / guiScale));
            if (tip != null && !tip.isEmpty()) {
                int tw = textRenderer.getWidth(tip);
                int tx = Math.min(mouseX + 12, width - tw - 8), ty = mouseY - 16;
                context.fill(tx - 3, ty - 3, tx + tw + 3, ty + 12, new Color(15, 10, 25, 240).getRGB());
                context.fill(tx - 2, ty - 2, tx + tw + 2, ty + 11, new Color(180, 40, 40, 180).getRGB());
                context.drawText(textRenderer, tip, tx, ty, new Color(220, 200, 210).getRGB(), true);
                break;
            }
        }
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        for (CategoryPanel p : categoryPanels) if (p.mouseClicked((int)(mx/guiScale),(int)(my/guiScale),btn)) return true;
        return super.mouseClicked(mx, my, btn);
    }
    @Override public boolean mouseReleased(double mx, double my, int btn) {
        for (CategoryPanel p : categoryPanels) if (p.mouseReleased((int)(mx/guiScale),(int)(my/guiScale),btn)) return true;
        return super.mouseReleased(mx, my, btn);
    }
    @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
        for (CategoryPanel p : categoryPanels) if (p.mouseScrolled((int)(mx/guiScale),(int)(my/guiScale),v)) return true;
        return super.mouseScrolled(mx, my, h, v);
    }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        for (CategoryPanel p : categoryPanels) if (p.mouseDragged((int)(mx/guiScale),(int)(my/guiScale),btn,dx,dy)) return true;
        return super.mouseDragged(mx, my, btn, dx, dy);
    }
    @Override public boolean charTyped(char c, int m) {
        for (CategoryPanel p : categoryPanels) if (p.charTyped(c, m)) return true;
        return super.charTyped(c, m);
    }
    @Override public boolean keyPressed(int k, int s, int m) {
        for (CategoryPanel p : categoryPanels) if (p.keyPressed(k, s, m)) return true;
        return super.keyPressed(k, s, m);
    }
    @Override public boolean shouldPause() { return false; }
}