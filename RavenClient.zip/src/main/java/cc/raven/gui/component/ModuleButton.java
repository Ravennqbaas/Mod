package cc.raven.gui.component;

import cc.raven.module.Module;
import cc.raven.module.setting.*;
import net.minecraft.client.gui.DrawContext;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ModuleButton {
    private final Module module;
    private int x, y, width, height;
    private boolean expanded = false, binding = false;
    private final List<SettingComponent> settingComponents = new ArrayList<>();

    public ModuleButton(Module module, int x, int y, int width, int height) {
        this.module = module; this.x = x; this.y = y; this.width = width; this.height = height;
    }

    private void buildSettings() {
        settingComponents.clear();
        int sy = y + height + 2;
        for (Setting s : module.getSettings()) {
            if (s instanceof KeybindSetting && s.getName().toLowerCase().contains("key")) continue;
            SettingComponent c = SettingComponent.create(s, x + 4, sy, width - 8, 12);
            settingComponents.add(c);
            sy += c.getTotalHeight() + 2;
        }
    }

    public void render(DrawContext ctx, int mx, int my, float delta) {
        boolean hovered = isHovered(mx, my), enabled = module.isEnabled();
        int bg = enabled ? new Color(180, 40, 40, hovered ? 120 : 90).getRGB() : new Color(30, 25, 40, hovered ? 100 : 70).getRGB();
        ctx.fill(x, y, x + width, y + height, bg);
        ctx.fill(x, y, x + 1, y + height, enabled ? new Color(200, 50, 50, 180).getRGB() : new Color(50, 40, 60, 120).getRGB());
        int tc = enabled ? new Color(255, 220, 220).getRGB() : new Color(160, 140, 160).getRGB();
        ctx.drawText(ctx.getTextRenderer(), module.getName(), x + 5, y + 2, tc, true);

        if (binding) {
            ctx.drawText(ctx.getTextRenderer(), "Press key...", x + width - 60, y + 2, new Color(255, 200, 50).getRGB(), true);
        } else if (module.getKey() != -1) {
            String kn = org.lwjgl.glfw.GLFW.glfwGetKeyName(module.getKey(), 0);
            if (kn != null) ctx.drawText(ctx.getTextRenderer(), kn.toUpperCase(), x + width - ctx.getTextRenderer().getWidth(kn.toUpperCase()) - 5, y + 2, new Color(160, 140, 160).getRGB(), true);
        }

        if (expanded) {
            int th = 0;
            for (SettingComponent c : settingComponents) th += c.getTotalHeight() + 2;
            ctx.fill(x, y + height, x + width, y + height + th + 6, new Color(20, 15, 30, 200).getRGB());
            int cy = y + height + 3;
            for (SettingComponent c : settingComponents) {
                c.setX(x + 4); c.setY(cy); c.setWidth(width - 8);
                c.render(ctx, mx, my, delta);
                cy += c.getTotalHeight() + 2;
            }
        }
    }

    public boolean isHovered(int mx, int my) {
        if (expanded) {
            int th = height;
            for (SettingComponent c : settingComponents) th += c.getTotalHeight() + 2;
            return mx >= x && mx <= x + width && my >= y && my <= y + th + 6;
        }
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    public boolean mouseClicked(int mx, int my, int btn) {
        if (!isHovered(mx, my)) return false;
        if (my <= y + height) {
            if (btn == 0) module.toggle();
            else if (btn == 1) { expanded = !expanded; if (expanded) buildSettings(); }
            else if (btn == 2) binding = !binding;
            return true;
        }
        if (expanded) for (SettingComponent c : settingComponents) if (c.mouseClicked(mx, my, btn)) return true;
        return false;
    }

    public boolean mouseReleased(int mx, int my, int btn) {
        if (expanded) for (SettingComponent c : settingComponents) if (c.mouseReleased(mx, my, btn)) return true;
        return false;
    }

    public boolean charTyped(char c, int m) {
        if (expanded) for (SettingComponent sc : settingComponents) if (sc.charTyped(c, m)) return true;
        return false;
    }

    public boolean keyPressed(int k, int s, int m) {
        if (binding) { module.setKey(k == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE ? -1 : k); binding = false; return true; }
        if (expanded) for (SettingComponent sc : settingComponents) if (sc.keyPressed(k, s, m)) return true;
        return false;
    }

    public Module getModule() { return module; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setWidth(int w) { this.width = w; }
}