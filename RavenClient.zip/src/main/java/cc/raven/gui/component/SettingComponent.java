package cc.raven.gui.component;

import cc.raven.module.setting.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import java.awt.Color;

public abstract class SettingComponent {
    protected Setting setting;
    protected int x, y, width, height;

    public SettingComponent(Setting setting, int x, int y, int width, int height) {
        this.setting = setting; this.x = x; this.y = y; this.width = width; this.height = height;
    }

    public abstract void render(DrawContext ctx, int mx, int my, float delta);
    public abstract boolean mouseClicked(int mx, int my, int btn);
    public boolean mouseReleased(int mx, int my, int btn) { return false; }
    public boolean charTyped(char c, int m) { return false; }
    public boolean keyPressed(int k, int s, int m) { return false; }
    public int getTotalHeight() { return height; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setWidth(int w) { this.width = w; }

    public static SettingComponent create(Setting s, int x, int y, int w, int h) {
        if (s instanceof BooleanSetting b) return new BooleanComp(b, x, y, w, h);
        if (s instanceof NumberSetting n) return new SliderComp(n, x, y, w, h);
        if (s instanceof ModeSetting m) return new ModeComp(m, x, y, w, h);
        if (s instanceof ColorSetting c) return new ColorComp(c, x, y, w, h);
        return new EmptyComp(s, x, y, w, h);
    }
}

class BooleanComp extends SettingComponent {
    private final BooleanSetting bs;
    BooleanComp(BooleanSetting s, int x, int y, int w, int h) { super(s, x, y, w, h); this.bs = s; }
    public void render(DrawContext ctx, int mx, int my, float d) {
        boolean hov = mx >= x && mx <= x + width && my >= y && my <= y + height;
        ctx.fill(x, y, x + width, y + height, bs.getValue() ? new Color(180, 40, 40, hov ? 180 : 140).getRGB() : new Color(40, 35, 50, hov ? 140 : 100).getRGB());
        ctx.drawText(ctx.getTextRenderer(), bs.getName() + ": " + (bs.getValue() ? "ON" : "OFF"), x + 3, y + 2, new Color(220, 200, 210).getRGB(), true);
    }
    public boolean mouseClicked(int mx, int my, int b) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) { bs.toggle(); return true; }
        return false;
    }
}

class SliderComp extends SettingComponent {
    private final NumberSetting ns;
    private boolean dragging;
    SliderComp(NumberSetting s, int x, int y, int w, int h) { super(s, x, y, w, h); this.ns = s; }
    public void render(DrawContext ctx, int mx, int my, float d) {
        float prog = (float)((ns.getValue() - ns.getMin()) / (ns.getMax() - ns.getMin()));
        ctx.fill(x, y, x + width, y + height, new Color(25, 20, 35, 200).getRGB());
        ctx.fill(x, y, x + (int)(width * prog), y + height, new Color(160, 35, 35, 180).getRGB());
        ctx.drawText(ctx.getTextRenderer(), ns.getName() + ": " + String.format("%.1f", ns.getValue()), x + 2, y + 1, new Color(220, 200, 210).getRGB(), true);
    }
    public boolean mouseClicked(int mx, int my, int b) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) { dragging = true; update(mx); return true; }
        return false;
    }
    public boolean mouseReleased(int mx, int my, int b) { dragging = false; return false; }
    private void update(int mx) {
        float prog = MathHelper.clamp((float)(mx - x) / width, 0f, 1f);
        ns.setValue(Math.round((ns.getMin() + prog * (ns.getMax() - ns.getMin())) / ns.getIncrement()) * ns.getIncrement());
    }
}

class ModeComp extends SettingComponent {
    private final ModeSetting ms;
    ModeComp(ModeSetting s, int x, int y, int w, int h) { super(s, x, y, w, h); this.ms = s; }
    public void render(DrawContext ctx, int mx, int my, float d) {
        boolean hov = mx >= x && mx <= x + width && my >= y && my <= y + height;
        ctx.fill(x, y, x + width, y + height, new Color(30, 25, 40, hov ? 200 : 150).getRGB());
        ctx.drawText(ctx.getTextRenderer(), ms.getName() + ": " + ms.getMode(), x + 3, y + 2, new Color(200, 180, 220).getRGB(), true);
    }
    public boolean mouseClicked(int mx, int my, int b) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) { ms.cycle(); return true; }
        return false;
    }
}

class ColorComp extends SettingComponent {
    private final ColorSetting cs;
    private boolean expanded;
    ColorComp(ColorSetting s, int x, int y, int w, int h) { super(s, x, y, w, h); this.cs = s; }
    public int getTotalHeight() { return expanded ? height + 30 : height; }
    public void render(DrawContext ctx, int mx, int my, float d) {
        boolean hov = mx >= x && mx <= x + width && my >= y && my <= y + height;
        ctx.fill(x, y, x + width, y + height, new Color(30, 25, 40, hov ? 200 : 150).getRGB());
        Color c = cs.getValue();
        ctx.fill(x + width - 14, y + 2, x + width - 2, y + height - 2, new Color(c.getRed(), c.getGreen(), c.getBlue(), 255).getRGB());
        ctx.drawText(ctx.getTextRenderer(), cs.getName(), x + 3, y + 2, new Color(220, 200, 210).getRGB(), true);
        if (expanded) {
            int sy = y + height + 2;
            int[] vals = {cs.getRed(), cs.getGreen(), cs.getBlue()};
            String[] labels = {"R", "G", "B"};
            for (int i = 0; i < 3; i++) {
                int cy = sy + i * 7;
                ctx.fill(x, cy, x + width, cy + 6, new Color(20, 15, 30, 200).getRGB());
                float prog = vals[i] / 255f;
                ctx.fill(x, cy, x + (int)(width * prog), cy + 6, new Color(i == 0 ? 255 : 100, i == 1 ? 255 : 60, i == 2 ? 255 : 80, 200).getRGB());
                ctx.drawText(ctx.getTextRenderer(), labels[i] + ":" + vals[i], x + 2, cy - 1, new Color(200, 180, 200).getRGB(), true);
            }
        }
    }
    public boolean mouseClicked(int mx, int my, int b) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + height) { expanded = !expanded; return true; }
        if (expanded) {
            int sy = y + height + 2;
            for (int i = 0; i < 3; i++) {
                int cy = sy + i * 7;
                if (mx >= x && mx <= x + width && my >= cy && my <= cy + 6) {
                    float prog = MathHelper.clamp((float)(mx - x) / width, 0f, 1f);
                    int val = (int)(prog * 255);
                    switch (i) {
                        case 0 -> cs.setValue(val, cs.getGreen(), cs.getBlue(), cs.getAlpha());
                        case 1 -> cs.setValue(cs.getRed(), val, cs.getBlue(), cs.getAlpha());
                        case 2 -> cs.setValue(cs.getRed(), cs.getGreen(), val, cs.getAlpha());
                    }
                    return true;
                }
            }
        }
        return false;
    }
}

class EmptyComp extends SettingComponent {
    EmptyComp(Setting s, int x, int y, int w, int h) { super(s, x, y, w, h); }
    public void render(DrawContext ctx, int mx, int my, float d) {}
    public boolean mouseClicked(int mx, int my, int b) { return false; }
}