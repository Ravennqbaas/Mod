package cc.raven.gui.component;

import cc.raven.RavenClient;
import cc.raven.module.Category;
import cc.raven.module.Module;
import net.minecraft.client.gui.DrawContext;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class CategoryPanel {
    private final Category category;
    private int x, y, width, maxHeight;
    private boolean expanded = true, dragging = false;
    private int dragOffX, dragOffY;
    private float scrollOffset = 0, targetScroll = 0, smoothScroll = 0;
    private final List<ModuleButton> buttons = new ArrayList<>();

    public CategoryPanel(Category category, int x, int y, int width, int maxHeight) {
        this.category = category; this.x = x; this.y = y; this.width = width; this.maxHeight = maxHeight;
        List<Module> mods = RavenClient.INSTANCE.getModuleManager().getModulesByCategory(category);
        for (int i = 0; i < mods.size(); i++)
            buttons.add(new ModuleButton(mods.get(i), x + 4, y + 28 + i * 17, width - 8, 15));
    }

    public void render(DrawContext ctx, int mx, int my, float delta, float smooth) {
        int headerH = 22;
        ctx.fill(x, y, x + width, y + headerH, getHeaderColor());
        ctx.fill(x, y + headerH, x + width, y + headerH + 1, new Color(180, 40, 40, 180).getRGB());
        String title = category.icon + " " + category.name;
        int tw = ctx.getTextRenderer().getWidth(title);
        ctx.drawText(ctx.getTextRenderer(), title, x + (width - tw) / 2, y + 5, new Color(220, 200, 210).getRGB(), true);

        if (expanded) {
            int panelH = Math.min(maxHeight, buttons.size() * 17 + 10);
            int totalH = buttons.size() * 17 + 10;
            int maxScroll = Math.max(0, totalH - panelH);
            ctx.enableScissor(x, y + headerH, x + width, y + headerH + panelH);
            smoothScroll += (targetScroll - smoothScroll) * Math.min(1f, delta * 0.3f);
            scrollOffset = smoothScroll;
            int cy = y + headerH + 4 - (int)scrollOffset;
            for (ModuleButton b : buttons) { b.setX(x + 4); b.setY(cy); b.setWidth(width - 8); b.render(ctx, mx, my, delta); cy += 17; }
            ctx.disableScissor();
            if (maxScroll > 0) {
                float sbH = (float)panelH / totalH * panelH;
                float sbY = y + headerH + (scrollOffset / maxScroll) * (panelH - sbH);
                ctx.fill(x + width - 3, (int)sbY, x + width - 1, (int)(sbY + sbH), new Color(180, 40, 40, 150).getRGB());
            }
        }
    }

    private int getHeaderColor() {
        return switch (category) {
            case COMBAT -> new Color(180, 40, 40, 220).getRGB();
            case MOVEMENT -> new Color(40, 140, 180, 220).getRGB();
            case PLAYER -> new Color(140, 100, 40, 220).getRGB();
            case RENDER -> new Color(100, 40, 180, 220).getRGB();
            case MISC -> new Color(40, 180, 100, 220).getRGB();
            case CLIENT -> new Color(140, 40, 140, 220).getRGB();
        };
    }

    public String getHoveredModuleDescription(int mx, int my) {
        if (!expanded) return null;
        for (ModuleButton b : buttons) if (b.isHovered(mx, my)) return b.getModule().getDescription();
        return null;
    }

    public boolean mouseClicked(int mx, int my, int btn) {
        if (mx >= x && mx <= x + width && my >= y && my <= y + 22) {
            if (btn == 0) expanded = !expanded;
            else if (btn == 1) { dragging = true; dragOffX = mx - x; dragOffY = my - y; }
            return true;
        }
        if (expanded) for (ModuleButton b : buttons) if (b.mouseClicked(mx, my, btn)) return true;
        return false;
    }

    public boolean mouseReleased(int mx, int my, int btn) {
        dragging = false;
        if (expanded) for (ModuleButton b : buttons) if (b.mouseReleased(mx, my, btn)) return true;
        return false;
    }

    public boolean mouseScrolled(int mx, int my, double amt) {
        if (expanded && mx >= x && mx <= x + width && my >= y + 23 && my <= y + Math.min(maxHeight, buttons.size() * 17 + 10) + 23) {
            targetScroll = Math.max(0, Math.min(buttons.size() * 17 + 10 - Math.min(maxHeight, buttons.size() * 17 + 10), targetScroll - amt * 25));
            return true;
        }
        return false;
    }

    public boolean mouseDragged(int mx, int my, int btn, double dx, double dy) {
        if (dragging) { x = mx - dragOffX; y = my - dragOffY; return true; }
        return false;
    }

    public boolean charTyped(char c, int m) {
        if (expanded) for (ModuleButton b : buttons) if (b.charTyped(c, m)) return true;
        return false;
    }

    public boolean keyPressed(int k, int s, int m) {
        if (expanded) for (ModuleButton b : buttons) if (b.keyPressed(k, s, m)) return true;
        return false;
    }
}